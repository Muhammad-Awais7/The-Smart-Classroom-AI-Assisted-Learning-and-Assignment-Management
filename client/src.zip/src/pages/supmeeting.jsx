// src/components/ArrangeMeeting.jsx
import React, { useState, useEffect } from "react";
import "bootstrap/dist/css/bootstrap.min.css";
import { useNavigate } from "react-router-dom";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faArrowLeft, faCalendarCheck, faUserGraduate, faTimesCircle } from "@fortawesome/free-solid-svg-icons";
import { db, auth } from "../firebase";
import { collection, addDoc, query, where, getDocs, serverTimestamp } from "firebase/firestore";

const ArrangeMeeting = () => {
  const navigate = useNavigate();
  const [formData, setFormData] = useState({
    students: [], // selected students array
    date: "",
    time: "",
    agenda: ""
  });
  const [assignedStudents, setAssignedStudents] = useState([]);

  // Fetch students assigned to this supervisor
  useEffect(() => {
    const fetchStudents = async () => {
      if (!auth.currentUser) return;

      try {
        const q = query(
          collection(db, "users"),
          where("supervisorId", "==", auth.currentUser.uid),
          where("role", "==", "student")
        );

        const snapshot = await getDocs(q);
        const students = snapshot.docs.map(doc => ({
          uid: doc.data().uid,
          name: doc.data().name
        }));
        setAssignedStudents(students);
      } catch (err) {
        console.error("Error fetching students:", err);
      }
    };

    fetchStudents();
  }, []);

  // Add student to selection
  const handleAddStudent = (e) => {
    const selectedName = e.target.value;
    if (!selectedName) return;

    // Prevent duplicates
    if (!formData.students.includes(selectedName)) {
      setFormData(prev => ({
        ...prev,
        students: [...prev.students, selectedName]
      }));
    }
  };

  // Remove student from selection
  const handleRemoveStudent = (name) => {
    setFormData(prev => ({
      ...prev,
      students: prev.students.filter(s => s !== name)
    }));
  };

  const handleChange = (e) => {
    setFormData(prev => ({
      ...prev,
      [e.target.name]: e.target.value
    }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    if (!formData.students.length) {
      alert("Please select at least one student");
      return;
    }

    try {
      // Get supervisor name from users collection
      const supervisorQuery = query(
        collection(db, "users"),
        where("uid", "==", auth.currentUser.uid)
      );
      const supervisorSnapshot = await getDocs(supervisorQuery);
      const supervisorData = supervisorSnapshot.docs[0]?.data();
      const supervisorName = supervisorData?.name || "Supervisor";

      // Add meeting for each selected student
      for (const studentName of formData.students) {
        const selectedStudent = assignedStudents.find(s => s.name === studentName);
        if (!selectedStudent) continue;

        await addDoc(collection(db, "meetings"), {
          studentUid: selectedStudent.uid,
          studentName: selectedStudent.name,
          supervisorUid: auth.currentUser.uid,
          supervisorName: supervisorName,
          date: formData.date,
          time: formData.time,
          agenda: formData.agenda,
          status: "pending",
          createdAt: serverTimestamp()
        });
      }

      alert(`Meeting scheduled successfully with: ${formData.students.join(", ")}`);
      setFormData({ students: [], date: "", time: "", agenda: "" });
    } catch (err) {
      console.error("Error scheduling meeting:", err);
      alert("Failed to schedule meeting. Check console.");
    }
  };

  return (
    <div className="d-flex flex-column min-vh-100" style={{ backgroundColor: "#e8f5e9" }}>
      {/* Header */}
      <header className="py-3 px-4 d-flex justify-content-between align-items-center shadow"
              style={{ backgroundColor: "#2e7d32", color: "#ffffff" }}>
        <h3 className="m-0">
          <FontAwesomeIcon icon={faCalendarCheck} className="me-2" />
          Arrange Meeting
        </h3>
        <button onClick={() => navigate("/SupervisorDashboard")}
                className="btn btn-light text-success fw-semibold">
          <FontAwesomeIcon icon={faArrowLeft} className="me-2" />
          Back to Supervisor Page
        </button>
      </header>

      {/* Main Content */}
      <main className="container py-5 flex-grow-1">
        <div className="row justify-content-center">
          <div className="col-12 col-md-6">
            <div className="card shadow-sm">
              <div className="card-body">
                <h5 className="card-title text-success mb-4">
                  <FontAwesomeIcon icon={faUserGraduate} className="me-2" />
                  Meeting Details
                </h5>

                <form onSubmit={handleSubmit}>
                  {/* Student Selection */}
                  <div className="mb-3">
                    <label className="form-label">Select Student or Multiple Students</label>
                    <select
                      className="form-select"
                      onChange={handleAddStudent}
                      value=""
                    >
                      <option value="">-- Choose Students --</option>
                      {assignedStudents.map(s => (
                        <option key={s.uid} value={s.name}>{s.name}</option>
                      ))}
                    </select>

                    {/* Show selected students */}
                    <div className="mt-3 d-flex flex-wrap gap-2">
                      {formData.students.map((name, idx) => (
                        <span
                          key={idx}
                          className="badge bg-success d-flex align-items-center p-2"
                          style={{ fontSize: "0.9rem" }}
                        >
                          {name}
                          <FontAwesomeIcon
                            icon={faTimesCircle}
                            className="ms-2"
                            style={{ cursor: "pointer" }}
                            onClick={() => handleRemoveStudent(name)}
                          />
                        </span>
                      ))}
                    </div>
                  </div>

                  {/* Date */}
                  <div className="mb-3">
                    <label className="form-label">Date</label>
                    <input type="date" name="date" className="form-control"
                           value={formData.date} onChange={handleChange} required />
                  </div>

                  {/* Time */}
                  <div className="mb-3">
                    <label className="form-label">Time</label>
                    <input type="time" name="time" className="form-control"
                           value={formData.time} onChange={handleChange} required />
                  </div>

                  {/* Agenda */}
                  <div className="mb-4">
                    <label className="form-label">Agenda</label>
                    <textarea name="agenda" className="form-control" rows="3"
                              value={formData.agenda} onChange={handleChange} required />
                  </div>

                  <button type="submit" className="btn btn-success w-100">
                    Schedule Meeting
                  </button>
                </form>

              </div>
            </div>
          </div>
        </div>
      </main>

      {/* Footer */}
      <footer className="text-white text-center py-3 mt-auto"
              style={{ backgroundColor: "#1b5e20" }}>
        <small>© 2025 Smart Past FYP Analyzer - Supervisor Panel</small>
      </footer>
    </div>
  );
};

export default ArrangeMeeting;
