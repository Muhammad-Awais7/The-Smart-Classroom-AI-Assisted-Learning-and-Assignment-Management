import { motion } from "framer-motion";
import { Rocket, ChevronRight } from "lucide-react";
import "bootstrap/dist/css/bootstrap.min.css";
import { useNavigate } from "react-router-dom";

export default function App() {
  const navigate = useNavigate();

  return (
    <div
      className="min-vh-100 d-flex flex-column justify-content-center align-items-center position-relative overflow-hidden"
      style={{
        background: "linear-gradient(135deg, #0f0c29, #302b63, #24243e)",
        color: "#fff",
        fontFamily: "'Segoe UI', Tahoma, Geneva, Verdana, sans-serif",
      }}
    >
      {/* --- Main Content Content (Z-Index ensures it sits above background) --- */}
      <div className="z-2 text-center px-3">
        {/* App Icon with Neon Glow */}
        <motion.div
          className="mb-4 d-inline-block"
          initial={{ rotate: -180, scale: 0, opacity: 0 }}
          animate={{ rotate: 0, scale: 1, opacity: 1 }}
          transition={{ duration: 1.5, type: "spring", stiffness: 60 }}
          style={{
            filter: "drop-shadow(0 0 20px rgba(0, 212, 255, 0.6))", // Neon Glow
          }}
        >
          <div
            className="p-4 rounded-circle"
            style={{
              background: "rgba(255, 255, 255, 0.05)",
              backdropFilter: "blur(10px)",
              border: "1px solid rgba(255, 255, 255, 0.1)",
            }}
          >
            <Rocket size={80} color="#00d4ff" />
          </div>
        </motion.div>

        {/* Title */}
        <motion.h1
          className="display-3 fw-bold mb-3"
          initial={{ y: -50, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ duration: 1 }}
        >
          Welcome to <span style={{ color: "#00d4ff" }}>Smart ClassRoom</span>
        </motion.h1>

        {/* Subtitle */}
        <motion.p
          className="lead mb-5"
          style={{ color: "rgba(255,255,255,0.7)", maxWidth: "600px", margin: "0 auto" }}
          initial={{ y: 50, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ delay: 0.5, duration: 1 }}
        >
          A smarter way to explore and manage your educational journey.
          <br />
          Streamline tasks, assignments, and tracking in one hub.
        </motion.p>

        {/* Call to Action Button */}
        <motion.button
          className="btn btn-lg px-5 py-3 d-inline-flex align-items-center gap-2 fw-bold rounded-pill"
          style={{
            background: "transparent",
            color: "#00d4ff",
            border: "2px solid #00d4ff",
            boxShadow: "0 0 15px rgba(0, 212, 255, 0.2)",
          }}
          initial={{ scale: 0.8, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          whileHover={{
            scale: 1.05,
            background: "#00d4ff",
            color: "#e11743", // Dark text on hover
            boxShadow: "0 0 30px rgba(0, 212, 255, 0.6)",
          }}
          whileTap={{ scale: 0.95 }}
          transition={{ type: "spring", stiffness: 200, delay: 0.8 }}
          onClick={() => navigate("/main")}
        >
          <Rocket size={24} /> Get Started <ChevronRight size={24} />
        </motion.button>
      </div>

      {/* --- Background Animated Orbs (Same as MainRoles) --- */}
      <motion.div
        className="position-absolute rounded-circle"
        style={{
          width: "500px",
          height: "500px",
          background: "#00d4ff", // Cyan Orb
          filter: "blur(180px)",
          top: "-15%",
          left: "-10%",
          opacity: 0.15,
          zIndex: 0,
        }}
        animate={{ x: [0, 50, 0], y: [0, 30, 0] }}
        transition={{ repeat: Infinity, duration: 15 }}
      />
      <motion.div
        className="position-absolute rounded-circle"
        style={{
          width: "400px",
          height: "400px",
          background: "#ff00cc", // Pink Orb
          filter: "blur(150px)",
          bottom: "-10%",
          right: "-10%",
          opacity: 0.15,
          zIndex: 0,
        }}
        animate={{ x: [0, -40, 0], y: [0, -40, 0] }}
        transition={{ repeat: Infinity, duration: 12 }}
      />
    </div>
  );
}