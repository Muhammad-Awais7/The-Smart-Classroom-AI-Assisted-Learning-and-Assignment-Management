// src/pages/PMOAnnouncements.jsx
import React, { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import {
  collection,
  query,
  where,
  onSnapshot,
  orderBy,
  updateDoc,
  doc,
  arrayUnion,
} from "firebase/firestore";
import { db } from "../firebase";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faArrowLeft, faBullhorn } from "@fortawesome/free-solid-svg-icons";

const PMOAnnouncements = () => {
  const [announcements, setAnnouncements] = useState([]);
  const navigate = useNavigate();

  useEffect(() => {
    const q = query(
      collection(db, "announcements"),
      where("visibleTo", "array-contains", "PMO"),
      orderBy("timestamp", "desc")
    );

    const unsubscribe = onSnapshot(q, (snapshot) => {
      const data = snapshot.docs.map((docSnap) => ({
        id: docSnap.id,
        ...docSnap.data(),
      }));
      setAnnouncements(data);
    });

    return () => unsubscribe();
  }, []);

  // ✅ Mark as Read (instant update - optimistic UI)
  const markAsRead = async (id) => {
    // 1️⃣ Optimistically update state immediately
    setAnnouncements((prev) =>
      prev.map((a) =>
        a.id === id ? { ...a, readBy: [...(a.readBy || []), "PMO"] } : a
      )
    );

    // 2️⃣ Then update Firestore
    const announcementRef = doc(db, "announcements", id);
    await updateDoc(announcementRef, {
      readBy: arrayUnion("PMO"),
    });
  };

  return (
    <div
      className="d-flex flex-column min-vh-100"
      style={{ background: "linear-gradient(135deg, #f0f7ff, #d6f5e8)" }}
    >
      {/* Header */}
      <header
        className="py-3 px-4 d-flex justify-content-between align-items-center shadow"
        style={{ backgroundColor: "#004d40", color: "#ffffff" }}
      >
        <h3 className="m-0">
          <FontAwesomeIcon icon={faBullhorn} className="me-2" />
          PMO - Announcements
        </h3>
        <button
          onClick={() => navigate("/PMODashboard")}
          className="btn btn-light text-success fw-semibold"
        >
          <FontAwesomeIcon icon={faArrowLeft} className="me-2" />
          Back
        </button>
      </header>

      {/* Main Content */}
      <main className="container flex-grow-1 py-5">
        <div className="row justify-content-center">
          <div className="col-12 col-md-10">
            {announcements.length === 0 ? (
              <div className="alert alert-info text-center shadow-sm rounded-3">
                No announcements yet.
              </div>
            ) : (
              announcements.map((a) => {
                const isRead = a.readBy?.includes("PMO");
                return (
                  <div
                    key={a.id}
                    className={`card mb-4 shadow-sm border-0 ${
                      isRead ? "bg-light" : "bg-white"
                    }`}
                  >
                    <div className="card-body">
                      <h5 className="card-title text-success">
                        {a.createdBy} - Announcement
                      </h5>
                      <p className="card-text">{a.message}</p>

                      {/* Timestamp */}
                      {a.timestamp?.toDate && (
                        <p className="text-muted small mb-2">
                          📅 {a.timestamp.toDate().toLocaleString()}
                        </p>
                      )}

                      {/* Mark as Read Button */}
                      {!isRead && (
                        <button
                          className="btn btn-outline-success btn-sm rounded-3"
                          onClick={() => markAsRead(a.id)}
                        >
                          Mark as Read
                        </button>
                      )}
                      {isRead && (
                        <span className="badge bg-secondary">Read ✔</span>
                      )}
                    </div>
                  </div>
                );
              })
            )}
          </div>
        </div>
      </main>

      {/* Footer */}
      <footer
        className="text-white text-center py-3 mt-auto"
        style={{ backgroundColor: "#00332d" }}
      >
        <small>© 2025 Smart Past FYP Analyzer - PMO Panel</small>
      </footer>
    </div>
  );
};

export default PMOAnnouncements;
