// src/components/PMOAddAnnouncement.jsx
import React, { useState } from "react";
import { Container, Form, Button, Alert, Navbar } from "react-bootstrap";
import { db } from "../firebase";
import { collection, addDoc, serverTimestamp } from "firebase/firestore";
import { useNavigate } from "react-router-dom";

export default function PMOAddAnnouncement() {
  const navigate = useNavigate();
  const [formData, setFormData] = useState({ title: "", message: "", audience: "all" });
  const [status, setStatus] = useState("");

  const handleChange = (e) => {
    setFormData((prev) => ({ ...prev, [e.target.name]: e.target.value }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setStatus("");

    // ✅ Map selection to roles
    let visibleTo = [];
    if (formData.audience === "all") {
      visibleTo = ["student", "supervisor"];
    } else if (formData.audience === "student") {
      visibleTo = ["student"];
    } else if (formData.audience === "supervisor") {
      visibleTo = ["supervisor"];
    }

    try {
      await addDoc(collection(db, "roleAnnouncements"), {
        title: formData.title,
        message: formData.message,
        visibleTo: visibleTo,   // ✅ store as array of roles
        createdBy: "PMO",
        createdAt: serverTimestamp(),
      });

      setStatus("✅ Announcement posted successfully!");
      setFormData({ title: "", message: "", audience: "all" });
    } catch (err) {
      console.error("Error adding announcement:", err);
      setStatus("❌ Error: " + err.message);
    }
  };

  return (
    <div className="d-flex flex-column min-vh-100" style={{ backgroundColor: "#f3f4f6" }}>
      {/* Navbar */}
      <Navbar style={{ background: "linear-gradient(90deg,#0d6efd,#6610f2)" }} variant="dark">
        <Container className="m-2 d-flex justify-content-between align-items-center">
          <Navbar.Brand className="fw-bold text-white">PMO - Announcements</Navbar.Brand>
          <Button variant="outline-light" onClick={() => navigate("/PMODashboard")}>
            Back
          </Button>
        </Container>
      </Navbar>

      <Container className="py-5">
        {status && <Alert variant="info">{status}</Alert>}
        <Form onSubmit={handleSubmit} className="shadow p-4 bg-white rounded">
          <Form.Group className="mb-3">
            <Form.Label>Title</Form.Label>
            <Form.Control
              type="text"
              name="title"
              value={formData.title}
              onChange={handleChange}
              required
            />
          </Form.Group>

          <Form.Group className="mb-3">
            <Form.Label>Message</Form.Label>
            <Form.Control
              as="textarea"
              rows={4}
              name="message"
              value={formData.message}
              onChange={handleChange}
              required
            />
          </Form.Group>

          {/* Role Audience Selection */}
          <Form.Group className="mb-3">
            <Form.Label>Send To</Form.Label>
            <Form.Select
              name="audience"
              value={formData.audience}
              onChange={handleChange}
            >
              <option value="all">All</option>
              <option value="student">Students Only</option>
              <option value="supervisor">Supervisors Only</option>
            </Form.Select>
          </Form.Group>

          <Button type="submit" className="w-100 btn-success">Post Announcement</Button>
        </Form>
      </Container>
    </div>
  );
}
