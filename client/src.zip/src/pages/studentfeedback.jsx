// src/components/StudentFeedback.jsx
import React, { useEffect, useState } from "react";
import "bootstrap/dist/css/bootstrap.min.css";
import { useNavigate } from "react-router-dom";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import {
  faArrowLeft,
  faComments,
  faChalkboardTeacher,
  faCheck,
} from "@fortawesome/free-solid-svg-icons";
import { db, auth } from "../firebase";
import {
  collection,
  query,
  where,
  onSnapshot,
  orderBy,
  addDoc,
  getDocs,
  serverTimestamp,
} from "firebase/firestore";

const StudentFeedback = () => {
  const navigate = useNavigate();
  const [feedbackList, setFeedbackList] = useState([]);
  const [readFeedbackIds, setReadFeedbackIds] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!auth.currentUser) {
      setLoading(false); // ✅ stop spinner if no user
      return;
    }

    const feedbackQuery = query(
      collection(db, "feedback"),
      where("studentUid", "==", auth.currentUser.uid),
      orderBy("createdAt", "desc")
    );

    const unsubscribe = onSnapshot(
      feedbackQuery,
      async (snapshot) => {
        if (snapshot.empty) {
          // ✅ No feedback case
          setFeedbackList([]);
          setReadFeedbackIds([]);
          setLoading(false);
          return;
        }

        const feedbacks = snapshot.docs.map((doc) => ({
          id: doc.id,
          ...doc.data(),
        }));

        // Fetch read feedback IDs
        const readQuery = query(
          collection(db, "studentFeedbackRead"),
          where("studentUid", "==", auth.currentUser.uid)
        );
        const readDocs = await getDocs(readQuery);
        const readIds = readDocs.docs.map((doc) => doc.data().feedbackId);

        setFeedbackList(feedbacks);
        setReadFeedbackIds(readIds);
        setLoading(false);
      },
      (error) => {
        console.error("Error fetching feedback:", error);
        setLoading(false); // ✅ stop spinner on error
      }
    );

    return () => unsubscribe();
  }, []);

  // 🔹 Mark feedback as read
  const markAsRead = async (id) => {
    try {
      await addDoc(collection(db, "studentFeedbackRead"), {
        studentUid: auth.currentUser.uid,
        feedbackId: id,
        readAt: serverTimestamp(),
      });
      setReadFeedbackIds((prev) => [...prev, id]); // update UI immediately
    } catch (err) {
      console.error("Error marking feedback as read:", err);
    }
  };

  return (
    <div
      className="d-flex flex-column min-vh-100"
      style={{ backgroundColor: "#e8f5e9" }}
    >
      {/* Header */}
      <header
        className="py-3 px-4 d-flex justify-content-between align-items-center shadow"
        style={{ backgroundColor: "#2e7d32", color: "#ffffff" }}
      >
        <h3 className="m-0">
          <FontAwesomeIcon icon={faComments} className="me-2" />
          My Feedback
        </h3>
        <button
          onClick={() => navigate("/StudentDashboard")}
          className="btn btn-light text-success fw-semibold"
        >
          <FontAwesomeIcon icon={faArrowLeft} className="me-2" />
          Back to Student Page
        </button>
      </header>

      {/* Main Content */}
      <main className="container py-5 flex-grow-1">
        <div className="row justify-content-center">
          <div className="col-12 col-md-8">
            {loading ? (
              <div className="text-center">
                <div
                  className="spinner-border text-success"
                  role="status"
                ></div>
              </div>
            ) : feedbackList.length === 0 ? (
              <div className="alert alert-info text-center shadow-sm">
                No feedback received yet.
              </div>
            ) : (
              feedbackList.map((fb) => (
                <div
                  key={fb.id}
                  className={`card mb-3 shadow-sm border-0 ${
                    readFeedbackIds.includes(fb.id)
                      ? "bg-success bg-opacity-25 border-success"
                      : ""
                  }`}
                >
                  <div className="card-body">
                    <h5 className="card-title text-success">
                      <FontAwesomeIcon
                        icon={faChalkboardTeacher}
                        className="me-2"
                      />
                      From {fb.supervisorName || "Supervisor"}
                    </h5>
                    <p className="card-text">{fb.feedback}</p>
                    <small className="text-muted d-block mb-2">
                      {fb.createdAt?.toDate().toLocaleString() || "Just now"}
                    </small>

                    <div className="d-flex justify-content-end">
                      <button
                        className={`btn btn-sm ${
                          readFeedbackIds.includes(fb.id)
                            ? "btn-outline-success"
                            : "btn-success"
                        }`}
                        disabled={readFeedbackIds.includes(fb.id)}
                        onClick={() => markAsRead(fb.id)}
                      >
                        <FontAwesomeIcon icon={faCheck} className="me-1" />
                        {readFeedbackIds.includes(fb.id)
                          ? "Acknowledged"
                          : "Mark as Read"}
                      </button>
                    </div>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>
      </main>

      {/* Footer */}
      <footer
        className="text-white text-center py-3 mt-auto"
        style={{ backgroundColor: "#1b5e20" }}
      >
        <small>© 2025 Smart Past FYP Analyzer - Student Panel</small>
      </footer>
    </div>
  );
};

export default StudentFeedback;
