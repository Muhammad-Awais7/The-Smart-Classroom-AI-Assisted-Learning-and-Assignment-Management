import React, { useEffect, useState } from "react";
import { auth } from "../firebase";
import { getSupervisorClassrooms } from "../services/classroomService";
import { useNavigate } from "react-router-dom";

export default function SupervisorClassrooms() {

  const [classes, setClasses] = useState([]);
  const navigate = useNavigate();

  useEffect(() => {

    const supervisorId = auth.currentUser?.uid;

    if (!supervisorId) return;

    async function loadClasses() {

      const data = await getSupervisorClassrooms(supervisorId);
      setClasses(data);
    }

    loadClasses();

  }, []);

  return (
    <div className="container mt-5">

      <h2>Your Classrooms</h2>

      {classes.map(cls => (
        <div
          key={cls.id}
          className="card mt-3 p-3"
          style={{ cursor: "pointer" }}
          onClick={() => navigate(`/classroom/${cls.id}`)}
        >
          <h5>{cls.className}</h5>
          <p>{cls.description}</p>
        </div>
      ))}

    </div>
  );
}
