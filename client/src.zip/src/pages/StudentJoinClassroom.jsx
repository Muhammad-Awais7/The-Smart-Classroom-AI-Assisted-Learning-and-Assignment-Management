import React, { useState } from "react";
import { auth } from "../firebase";
import { requestJoinClassroom } from "../services/classroomService";

export default function StudentJoinClassroom() {

  const [code, setCode] = useState("");
  const [msg, setMsg] = useState("");

  const handleJoin = async () => {

    try {

      await requestJoinClassroom(
        code,
        auth.currentUser.uid
      );

      setMsg("Join request sent!");

    } catch (e) {
      alert(e.message);
    }
  };

  return (
    <div className="container mt-5">

      <h2>Join Classroom</h2>

      <input
        className="form-control mt-3"
        placeholder="Enter Class Code"
        value={code}
        onChange={(e) => setCode(e.target.value)}
      />

      <button
        className="btn btn-primary mt-3"
        onClick={handleJoin}
      >
        Send Request
      </button>

      <p className="text-success mt-3">{msg}</p>

    </div>
  );
}
