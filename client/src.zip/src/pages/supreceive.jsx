// src/components/ReceiveAnnouncements.jsx
import React, { useEffect, useState } from "react";
import { db, auth } from "../firebase";
import {
  collection,
  query,
  orderBy,
  onSnapshot,
  addDoc,
  where,
  getDocs,
  serverTimestamp,
} from "firebase/firestore";
import { Container, Card, Spinner, Alert, Button } from "react-bootstrap";

export default function ReceiveAnnouncements() {
  const [announcements, setAnnouncements] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [justRead, setJustRead] = useState([]); // ✅ track recently marked as read

  useEffect(() => {
    if (!auth.currentUser) {
      setError("Not logged in.");
      setLoading(false);
      return;
    }

    const q = query(
      collection(db, "announcements"),
      orderBy("createdAt", "desc")
    );

    const unsubscribe = onSnapshot(
      q,
      async (snapshot) => {
        const allAnnouncements = snapshot.docs.map((d) => ({
          id: d.id,
          ...d.data(),
        }));

        // 🔹 Fetch announcements user already read
        const readQuery = query(
          collection(db, "userAnnouncements"),
          where("uid", "==", auth.currentUser.uid)
        );
        const readDocs = await getDocs(readQuery);
        const readIds = readDocs.docs.map((doc) => doc.data().announcementId);

        // 🔹 Filter unread announcements
        const unread = allAnnouncements.filter(
          (a) => !readIds.includes(a.id)
        );

        setAnnouncements(unread);
        setLoading(false);
      },
      (err) => {
        console.error("Error fetching announcements:", err);
        setError("Failed to load announcements.");
        setLoading(false);
      }
    );

    return () => unsubscribe();
  }, []);

  // 🔹 Mark as Read
  const markAsRead = async (id) => {
    try {
      await addDoc(collection(db, "userAnnouncements"), {
        uid: auth.currentUser.uid,
        announcementId: id,
        readAt: serverTimestamp(),
      });

      // ✅ Highlight immediately
      setJustRead((prev) => [...prev, id]);
    } catch (err) {
      console.error("Error marking as read:", err);
      setError("Failed to mark as read.");
    }
  };

  if (loading) {
    return (
      <Container className="text-center mt-5">
        <Spinner animation="border" role="status" />
      </Container>
    );
  }

  if (error) {
    return (
      <Container className="mt-5">
        <Alert variant="danger">{error}</Alert>
      </Container>
    );
  }

  return (
    <Container className="mt-5">
      <h3 className="mb-4 text-center">📢 Announcements</h3>

      {announcements.length === 0 ? (
        <p className="text-center">No new announcements.</p>
      ) : (
        announcements.map((a) => (
          <Card
            key={a.id}
            className={`mb-3 shadow-sm ${
              justRead.includes(a.id) ? "bg-success bg-opacity-25 border-success" : ""
            }`}
          >
            <Card.Body>
              <Card.Title>{a.title}</Card.Title>
              <Card.Text>{a.message}</Card.Text>
              <small className="text-muted">
                Audience: {a.audience || "all"} |{" "}
                {a.createdAt?.toDate().toLocaleString() || "Just now"}
              </small>
              <div className="d-flex justify-content-end mt-2">
                <Button
                  variant={justRead.includes(a.id) ? "outline-success" : "success"}
                  size="sm"
                  disabled={justRead.includes(a.id)} // ✅ disable once clicked
                  onClick={() => markAsRead(a.id)}
                >
                  {justRead.includes(a.id) ? "✔ Marked" : "✅ Mark as Read"}
                </Button>
              </div>
            </Card.Body>
          </Card>
        ))
      )}
    </Container>
  );
}
