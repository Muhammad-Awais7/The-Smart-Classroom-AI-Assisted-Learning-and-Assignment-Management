import React, { useState } from "react";
import "bootstrap/dist/css/bootstrap.min.css";
import { useNavigate } from "react-router-dom";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import {
  faCommentDots,
  faArrowLeft,
  faPaperPlane
} from "@fortawesome/free-solid-svg-icons";

const CommentOnProject = () => {
  const navigate = useNavigate();
  const [comment, setComment] = useState("");
  const [selectedProject, setSelectedProject] = useState("");
  const [submitted, setSubmitted] = useState(false);

  const handleSubmit = (e) => {
    e.preventDefault();
    if (selectedProject && comment.trim()) {
      setSubmitted(true);
      setComment("");
      setSelectedProject("");
      setTimeout(() => setSubmitted(false), 3000);
    }
  };

  return (
    <div className="d-flex flex-column min-vh-100" style={{ backgroundColor: "#e8f5e9" }}>
      {/* Header */}
      <header
        className="py-3 px-4 d-flex justify-content-between align-items-center shadow"
        style={{ backgroundColor: "#2e7d32", color: "#ffffff" }}
      >
        <h3 className="m-0">
          <FontAwesomeIcon icon={faCommentDots} className="me-2" />
          Comment on Project
        </h3>
        <button
          onClick={() => navigate("/SupervisorDashboard")}
          className="btn btn-light text-success fw-semibold"
        >
          <FontAwesomeIcon icon={faArrowLeft} className="me-2" />
          Back to Supervisor Page
        </button>
      </header>

      {/* Main Content */}
      <main className="container flex-grow-1 py-5">
        <div className="row justify-content-center">
          <div className="col-12 col-md-8 col-lg-6">
            <div className="card border-0 shadow-sm">
              <div className="card-body">
                <h5 className="card-title mb-4 text-success">Leave a Comment</h5>
                <form onSubmit={handleSubmit}>
                  {/* Project Selection */}
                  <div className="mb-3">
                    <label htmlFor="projectSelect" className="form-label">Select Project</label>
                    <select
                      className="form-select"
                      id="projectSelect"
                      value={selectedProject}
                      onChange={(e) => setSelectedProject(e.target.value)}
                      required
                    >
                      <option value="" disabled>Choose a project...</option>
                      <option value="proj1">AI Chatbot for Campus</option>
                      <option value="proj2">Smart Waste Bin</option>
                      <option value="proj3">IoT Garden Monitoring</option>
                    </select>
                  </div>

                  {/* Comment Textarea */}
                  <div className="mb-3">
                    <label htmlFor="commentText" className="form-label">Your Comment</label>
                    <textarea
                      className="form-control"
                      id="commentText"
                      rows="5"
                      placeholder="Write your comment here..."
                      value={comment}
                      onChange={(e) => setComment(e.target.value)}
                      required
                    ></textarea>
                  </div>

                  {/* Submit Button */}
                  <button type="submit" className="btn btn-success w-100">
                    <FontAwesomeIcon icon={faPaperPlane} className="me-2" />
                    Submit Comment
                  </button>
                </form>

                {/* Success Alert */}
                {submitted && (
                  <div className="alert alert-success text-center mt-3">
                    Comment submitted successfully!
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>
      </main>

      {/* Footer */}
      <footer
        className="text-white text-center py-3 mt-auto"
        style={{ backgroundColor: "#1b5e20" }}
      >
        <small>© 2025 Smart Past FYP Analyzer - Supervisor Panel</small>
      </footer>
    </div>
  );
};

export default CommentOnProject;
