// src/components/ProvideFeedback.jsx
import React, { useState, useEffect } from "react";
import "bootstrap/dist/css/bootstrap.min.css";
import { useNavigate } from "react-router-dom";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import {
  faComments,
  faPaperPlane,
  faArrowLeft,
  faUserGraduate,
  faTimes,
} from "@fortawesome/free-solid-svg-icons";
import { db, auth } from "../firebase";
import {
  collection,
  addDoc,
  query,
  where,
  getDocs,
  serverTimestamp,
} from "firebase/firestore";

const ProvideFeedback = () => {
  const navigate = useNavigate();
  const [feedback, setFeedback] = useState("");
  const [submitted, setSubmitted] = useState(false);
  const [assignedStudents, setAssignedStudents] = useState([]);
  const [selectedStudents, setSelectedStudents] = useState([]); // ✅ array

  // 🔹 Fetch students assigned to this supervisor
  useEffect(() => {
    const fetchStudents = async () => {
      if (!auth.currentUser) return;

      try {
        const q = query(
          collection(db, "users"),
          where("supervisorId", "==", auth.currentUser.uid),
          where("role", "==", "student")
        );

        const snapshot = await getDocs(q);
        const students = snapshot.docs.map((doc) => ({
          uid: doc.data().uid,
          name: doc.data().name,
        }));
        setAssignedStudents(students);
      } catch (err) {
        console.error("Error fetching students:", err);
      }
    };

    fetchStudents();
  }, []);

  // 🔹 Add student to list
  const handleStudentSelect = (e) => {
    const uid = e.target.value;
    if (!uid) return;

    const studentObj = assignedStudents.find((s) => s.uid === uid);
    if (!studentObj) return;

    if (!selectedStudents.find((s) => s.uid === uid)) {
      setSelectedStudents([...selectedStudents, studentObj]);
    }
    e.target.value = ""; // reset dropdown
  };

  // 🔹 Remove student from list
  const removeStudent = (uid) => {
    setSelectedStudents(selectedStudents.filter((s) => s.uid !== uid));
  };

  // 🔹 Submit Feedback
  const handleSubmit = async (e) => {
    e.preventDefault();

    if (!selectedStudents.length || !feedback.trim()) {
      alert("Please select at least one student and write feedback.");
      return;
    }

    try {
      // Get supervisor name
      const supervisorQuery = query(
        collection(db, "users"),
        where("uid", "==", auth.currentUser.uid)
      );
      const supervisorSnapshot = await getDocs(supervisorQuery);
      const supervisorData = supervisorSnapshot.docs[0]?.data();
      const supervisorName = supervisorData?.name || "Supervisor";

      // Add feedback for each selected student
      for (const studentObj of selectedStudents) {
        await addDoc(collection(db, "feedback"), {
          studentUid: studentObj.uid,
          studentName: studentObj.name,
          supervisorUid: auth.currentUser.uid,
          supervisorName: supervisorName,
          feedback: feedback,
          createdAt: serverTimestamp(),
        });
      }

      setSubmitted(true);
      setFeedback("");
      setSelectedStudents([]);
      setTimeout(() => setSubmitted(false), 3000);
    } catch (err) {
      console.error("Error submitting feedback:", err);
      alert("Failed to submit feedback. Check console.");
    }
  };

  return (
    <div
      className="d-flex flex-column min-vh-100"
      style={{ backgroundColor: "#e8f5e9" }}
    >
      {/* Header with Back Button */}
      <header
        className="py-3 px-4 d-flex justify-content-between align-items-center shadow"
        style={{ backgroundColor: "#2e7d32", color: "#ffffff" }}
      >
        <h3 className="m-0">
          <FontAwesomeIcon icon={faComments} className="me-2" />
          Provide Feedback
        </h3>
        <button
          onClick={() => navigate("/SupervisorDashboard")}
          className="btn btn-light text-success fw-semibold"
          style={{ backgroundColor: "#ffffff", borderColor: "#c8e6c9" }}
        >
          <FontAwesomeIcon icon={faArrowLeft} className="me-2" />
          Back to Supervisor Page
        </button>
      </header>

      {/* Main Content */}
      <main className="container flex-grow-1 py-5">
        <div className="row justify-content-center">
          <div className="col-12 col-md-8 col-lg-6">
            <div className="card border-0 shadow-sm">
              <div className="card-body">
                <h5 className="card-title mb-4 text-success">
                  <FontAwesomeIcon icon={faUserGraduate} className="me-2" />
                  Write Feedback
                </h5>
                <form onSubmit={handleSubmit}>
                  {/* Student Dropdown */}
                  <div className="mb-3">
                    <label className="form-label">Select Student(s)</label>
                    <select
                      className="form-select"
                      onChange={handleStudentSelect}
                      defaultValue=""
                    >
                      <option value="">-- Choose a Student --</option>
                      {assignedStudents.map((s) => (
                        <option key={s.uid} value={s.uid}>
                          {s.name}
                        </option>
                      ))}
                    </select>

                    {/* Show selected students as badges */}
                    <div className="mt-2">
                      {selectedStudents.map((s) => (
                        <span
                          key={s.uid}
                          className="badge bg-success me-2 mb-2 d-inline-flex align-items-center"
                          style={{ fontSize: "0.9rem" }}
                        >
                          {s.name}
                          <FontAwesomeIcon
                            icon={faTimes}
                            className="ms-2"
                            style={{ cursor: "pointer" }}
                            onClick={() => removeStudent(s.uid)}
                          />
                        </span>
                      ))}
                    </div>
                  </div>

                  {/* Feedback Textarea */}
                  <div className="mb-3">
                    <label htmlFor="feedbackText" className="form-label">
                      Your Feedback
                    </label>
                    <textarea
                      className="form-control"
                      id="feedbackText"
                      rows="5"
                      value={feedback}
                      placeholder="Write constructive feedback here..."
                      onChange={(e) => setFeedback(e.target.value)}
                      required
                    ></textarea>
                  </div>

                  {/* Submit Button */}
                  <button type="submit" className="btn btn-success w-100">
                    <FontAwesomeIcon icon={faPaperPlane} className="me-2" />
                    Submit Feedback
                  </button>
                </form>

                {/* Success Message */}
                {submitted && (
                  <div
                    className="alert alert-success mt-3 text-center"
                    role="alert"
                  >
                    Feedback submitted successfully!
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>
      </main>

      {/* Footer */}
      <footer
        className="text-white text-center py-3 mt-auto"
        style={{ backgroundColor: "#1b5e20" }}
      >
        <small>© 2025 Smart Past FYP Analyzer - Supervisor Panel</small>
      </footer>
    </div>
  );
};

export default ProvideFeedback;
