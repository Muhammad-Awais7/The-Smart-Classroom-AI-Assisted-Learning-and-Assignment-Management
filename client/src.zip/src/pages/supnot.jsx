// src/pages/SupervisorAnnouncements.jsx
import React, { useEffect, useState } from "react";
import { db, auth } from "../firebase";
import {
  collection,
  query,
  where,
  onSnapshot,
  orderBy,
  updateDoc,
  doc,
  arrayUnion,
} from "firebase/firestore";
import { useNavigate } from "react-router-dom";
import { Button, Card, Container, Row, Col, Badge } from "react-bootstrap";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faArrowLeft, faBullhorn } from "@fortawesome/free-solid-svg-icons";

export default function SupervisorAnnouncements() {
  const [announcements, setAnnouncements] = useState([]);
  const navigate = useNavigate();
  const currentUser = auth.currentUser;

  useEffect(() => {
    const q = query(
      collection(db, "roleAnnouncements"),
      where("visibleTo", "array-contains", "supervisor"),
      orderBy("createdAt", "desc")
    );

    const unsubscribe = onSnapshot(q, (snapshot) => {
      setAnnouncements(snapshot.docs.map((docSnap) => ({ id: docSnap.id, ...docSnap.data() })));
    });

    return () => unsubscribe();
  }, []);

  // ✅ Mark as Read
  const markAsRead = async (id) => {
    if (!currentUser) return;
    const announcementRef = doc(db, "roleAnnouncements", id);
    await updateDoc(announcementRef, {
      readBy: arrayUnion(currentUser.uid),
    });
  };

  return (
    <div
      className="d-flex flex-column min-vh-100"
      style={{ background: "linear-gradient(135deg, #f9fbfd, #e6f7ff)" }}
    >
      {/* Header */}
      <header
        className="py-3 px-4 d-flex justify-content-between align-items-center shadow-sm"
        style={{ backgroundColor: "#004085", color: "#ffffff" }}
      >
        <h3 className="m-0">
          <FontAwesomeIcon icon={faBullhorn} className="me-2" />
          Supervisor Announcements
        </h3>
        <Button
          variant="light"
          onClick={() => navigate("/SupervisorDashboard")}
          className="fw-semibold"
        >
          <FontAwesomeIcon icon={faArrowLeft} className="me-2" />
          Back
        </Button>
      </header>

      {/* Main Content */}
      <Container className="flex-grow-1 py-5">
        <Row className="justify-content-center">
          <Col xs={12} md={10} lg={8}>
            {announcements.length === 0 ? (
              <div className="alert alert-info text-center shadow-sm rounded-3">
                No announcements yet.
              </div>
            ) : (
              announcements.map((a) => {
                const isRead = a.readBy?.includes(currentUser?.uid);

                return (
                  <Card
                    key={a.id}
                    className={`mb-4 shadow-sm border-0 rounded-4 ${
                      isRead ? "bg-light" : "bg-white"
                    }`}
                  >
                    <Card.Body>
                      <Card.Title className="fw-bold text-primary">{a.title}</Card.Title>
                      <Card.Text>{a.message}</Card.Text>

                      {/* Timestamp */}
                      {a.createdAt?.toDate && (
                        <p className="text-muted small mb-3">
                          📅 {a.createdAt.toDate().toLocaleString()}
                        </p>
                      )}

                      {/* Mark as Read Button */}
                      {!isRead ? (
                        <Button
                          size="sm"
                          variant="outline-primary"
                          className="rounded-3"
                          onClick={() => markAsRead(a.id)}
                        >
                          Mark as Read
                        </Button>
                      ) : (
                        <Badge bg="success" className="rounded-pill px-3 py-2">
                          Read ✔
                        </Badge>
                      )}
                    </Card.Body>
                  </Card>
                );
              })
            )}
          </Col>
        </Row>
      </Container>

      {/* Footer */}
      <footer
        className="text-white text-center py-3 mt-auto"
        style={{ backgroundColor: "#002752" }}
      >
        <small>© 2025 Smart Past FYP Analyzer - Supervisor Panel</small>
      </footer>
    </div>
  );
}
