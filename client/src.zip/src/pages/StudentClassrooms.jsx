import React, { useEffect, useState } from "react";
import { auth } from "../firebase";
import { getStudentClassrooms } from "../services/classroomService";

export default function StudentClassrooms() {

  const [classes, setClasses] = useState([]);

  useEffect(() => {

    const studentId = auth.currentUser?.uid;

    if (!studentId) return;

    async function loadData() {

      const data = await getStudentClassrooms(studentId);
      setClasses(data);
    }

    loadData();

  }, []);

  return (
    <div className="container mt-5">

      <h2>My Classrooms</h2>

      {classes.map((cls, i) => (
        <div key={i} className="card mt-3 p-3">
          Classroom ID: {cls.classroomId}
        </div>
      ))}

    </div>
  );
}
