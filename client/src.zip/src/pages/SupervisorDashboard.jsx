import React from "react";
import "bootstrap/dist/css/bootstrap.min.css";
import { useNavigate } from "react-router-dom";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import {
  faHome,
  faBell,
  faCommentAlt,
  faCheckCircle,
  faFileAlt,
  faTasks,
  faComments,
  faChalkboardTeacher,
  faArrowRight
} from "@fortawesome/free-solid-svg-icons";
import { motion } from "framer-motion";

const SupervisorPanel = () => {
  const navigate = useNavigate();

  const handleNavigate = (path) => {
    navigate(path);
  };

  // --- Animation Variants ---
  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: { staggerChildren: 0.15 }
    }
  };

  const itemVariants = {
    hidden: { y: 30, opacity: 0 },
    visible: { y: 0, opacity: 1 }
  };

  // --- Task Configuration ---
  // Assigned specific neon colors to groups of tasks for visual hierarchy
  const tasks = [
    { 
      icon: faHome, 
      label: "Main Page", 
      route: "/main", 
      color: "#00d4ff", // Cyan for Navigation
      desc: "Return to the main landing page" 
    },
    { 
      icon: faChalkboardTeacher, 
      label: "Create ClassRoom", 
     route: "/create-classroom",
      color: "#5500ff", // Orange for Alerts
      desc: "Instructor Class" 
    },
      { 
      icon: faChalkboardTeacher, 
      label: "View Classroom", 
     route: "/supervisor-classes",
      color: "#5500ff", // Orange for Alerts
      desc: "Instructor Class" 
    },


{ 
      icon: faBell, 
      label: "Notifications", 
      route: "/supnot", 
      color: "#ff9900", // Orange for Alerts
      desc: "Check latest system updates" 
    },

    { 
      icon: faCheckCircle, 
      label: "Approve Ideas", 
      route: "/supappidea", 
      color: "#00ff9d", // Green for Approvals
      desc: "Review and approve project proposals" 
    },
    { 
      icon: faCommentAlt, 
      label: "Provide Feedback", 
      route: "/supfeedback", 
      color: "#ff00cc", // Pink for Core Task
      desc: "Give remarks on student progress" 
    },
    { 
      icon: faFileAlt, 
      label: "Review Reports", 
      route: "/supreviewreps", 
      color: "#ff00cc", // Pink for Core Task
      desc: "Check final project documentation" 
    },
    { 
      icon: faTasks, 
      label: "Student Queries", 
      route: "/suptrack", 
      color: "#bd00ff", // Purple for Interaction
      desc: "Answer questions from students" 
    },
    { 
      icon: faComments, 
      label: "Meetings", 
      route: "/supmeeting", 
      color: "#bd00ff", // Purple for Interaction
      desc: "Schedule and manage consultations" 
    },
  ];

  return (
    <div
      className="d-flex flex-column min-vh-100 position-relative overflow-hidden"
      style={{
        background: "linear-gradient(135deg, #0f0c29, #302b63, #24243e)",
        fontFamily: "'Segoe UI', Tahoma, Geneva, Verdana, sans-serif",
        color: "#fff"
      }}
    >
      {/* --- Background Animated Orbs --- */}
      <motion.div
        className="position-absolute rounded-circle"
        style={{
          width: "500px", height: "500px", background: "#ff00cc", // Pink Orb
          filter: "blur(180px)", top: "-15%", right: "-10%", opacity: 0.2, zIndex: 0
        }}
        animate={{ scale: [1, 1.2, 1], x: [0, -30, 0] }}
        transition={{ repeat: Infinity, duration: 15 }}
      />
      <motion.div
        className="position-absolute rounded-circle"
        style={{
          width: "400px", height: "400px", background: "#333399", // Blue/Purple Orb
          filter: "blur(150px)", bottom: "-10%", left: "-10%", opacity: 0.2, zIndex: 0
        }}
        animate={{ scale: [1, 1.1, 1], y: [0, -40, 0] }}
        transition={{ repeat: Infinity, duration: 12 }}
      />

      {/* --- Navbar --- */}
      <motion.header
        className="py-3 px-4 shadow-lg d-flex justify-content-between align-items-center"
        style={{
          background: "rgba(255, 255, 255, 0.05)",
          backdropFilter: "blur(10px)",
          borderBottom: "1px solid rgba(255, 255, 255, 0.1)",
          zIndex: 10
        }}
        initial={{ y: -50, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
      >
        <h3 className="m-0 fw-bold d-flex align-items-center text-white">
          <div 
            className="d-flex align-items-center justify-content-center rounded-circle me-3"
            style={{ width: '45px', height: '45px', background: 'rgba(255,255,255,0.1)' }}
          >
            <FontAwesomeIcon icon={faChalkboardTeacher} style={{ color: "#ff00cc" }} />
          </div>
          Instructor <span className="fw-light ms-2 opacity-75">Dashboard</span>
        </h3>

        <button 
            className="btn btn-outline-light btn-sm rounded-pill px-3"
            onClick={() => handleNavigate("/")}
            style={{ borderColor: "rgba(255,255,255,0.3)" }}
        >
            Logout
        </button>
      </motion.header>

      {/* --- Main Content --- */}
      <main className="flex-grow-1 container py-5 d-flex flex-column justify-content-center position-relative" style={{ zIndex: 5 }}>
        
        <motion.div 
            className="text-center mb-5"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
        >
          <h2 className="fw-bold display-5">Instructor Control Center</h2>
          <p className="text-white-50 fs-5">Manage your students and their projects</p>
        </motion.div>

        <motion.div 
          className="row g-4 justify-content-center"
          variants={containerVariants}
          initial="hidden"
          animate="visible"
        >
          {tasks.map((item, idx) => (
            <div className="col-md-6 col-lg-4 col-xl-3" key={idx}>
              <motion.div
                variants={itemVariants}
                whileHover={{ 
                    y: -10, 
                    boxShadow: `0 0 30px ${item.color}60`,
                    borderColor: item.color 
                }}
                whileTap={{ scale: 0.98 }}
                onClick={() => handleNavigate(item.route)}
                className="card h-100 p-4 border-0 text-start text-white position-relative overflow-hidden"
                style={{
                  background: "rgba(255, 255, 255, 0.05)",
                  backdropFilter: "blur(15px)",
                  border: "1px solid rgba(255, 255, 255, 0.1)",
                  borderRadius: "20px",
                  cursor: "pointer"
                }}
              >
                {/* Icon Container */}
                <div 
                    className="mb-3 rounded-circle d-flex align-items-center justify-content-center"
                    style={{ 
                        width: '50px', 
                        height: '50px', 
                        background: `${item.color}20`,
                        border: `1px solid ${item.color}40`,
                        color: item.color 
                    }}
                >
                    <FontAwesomeIcon icon={item.icon} size="lg" />
                </div>

                <div className="d-flex justify-content-between align-items-center mb-2">
                    <h5 className="fw-bold mb-0">{item.label}</h5>
                    <FontAwesomeIcon icon={faArrowRight} className="text-white-50 small" />
                </div>
                
                <p className="small text-white-50 mb-0" style={{ fontSize: '0.85rem' }}>{item.desc}</p>
                
                {/* Hover Glow Effect overlay */}
                <div 
                    className="position-absolute bottom-0 end-0 p-5"
                    style={{
                        background: item.color,
                        filter: "blur(60px)",
                        opacity: 0.1,
                        borderRadius: "50%"
                    }}
                />
              </motion.div>
            </div>
          ))}
        </motion.div>
      </main>

      {/* --- Footer --- */}
      <motion.footer
        className="text-white text-center py-3"
        style={{
            background: "rgba(0,0,0,0.2)",
            backdropFilter: "blur(5px)",
            borderTop: "1px solid rgba(255, 255, 255, 0.05)"
        }}
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 1 }}
      >
        <small className="opacity-50">© 2025 Smart ClassRoom - Instructor Panel</small>
      </motion.footer>
    </div>
  );
};

export default SupervisorPanel;