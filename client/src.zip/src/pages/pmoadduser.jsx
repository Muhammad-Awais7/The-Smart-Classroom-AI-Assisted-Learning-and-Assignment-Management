import React, { useState, useEffect } from "react";
import { Container, Form, Button, Row, Col, Alert, Navbar } from "react-bootstrap";
import { auth, db } from "../firebase";
import { createUserWithEmailAndPassword } from "firebase/auth";
import { collection, setDoc, doc, getDocs, serverTimestamp, query, where } from "firebase/firestore";
import { useNavigate } from "react-router-dom";
import { motion } from "framer-motion"; // Animation library
import { UserPlus, ArrowLeft, User, Mail, Lock, Shield } from "lucide-react"; // Icons

export default function PMOAddUser() {
  const navigate = useNavigate();
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    password: "",
    role: "",
    supervisorId: ""
  });
  const [supervisors, setSupervisors] = useState([]);
  const [message, setMessage] = useState("");
  const [error, setError] = useState(false); // To style alert differently

  // Fetch Supervisors
  useEffect(() => {
    async function fetchSupervisors() {
      const q = query(collection(db, "users"), where("role", "==", "supervisor"));
      const snapshot = await getDocs(q);
      const supervisorList = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
      setSupervisors(supervisorList);
    }
    fetchSupervisors();
  }, []);

  const handleChange = (e) => {
    setFormData(prev => ({ ...prev, [e.target.name]: e.target.value }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setMessage("");
    setError(false);
    try {
      const userCredential = await createUserWithEmailAndPassword(auth, formData.email, formData.password);
      const uid = userCredential.user.uid;

      await setDoc(doc(db, "users", uid), {
        uid,
        name: formData.name,
        email: formData.email,
        role: formData.role,
        supervisorId: formData.role === "student" ? formData.supervisorId : null,
        createdAt: serverTimestamp()
      });

      setMessage(`${formData.role.toUpperCase()} added successfully!`);
      setError(false);
      setFormData({ name: "", email: "", password: "", role: "", supervisorId: "" });

    } catch (err) {
      console.error(err);
      setError(true);
      setMessage(err.message);
    }
  };

  // Custom Input Style
  const inputStyle = {
    background: "rgba(255, 255, 255, 0.05)",
    border: "1px solid rgba(255, 255, 255, 0.2)",
    color: "#fff",
    backdropFilter: "blur(5px)"
  };

  return (
    <div
      className="d-flex flex-column min-vh-100 position-relative overflow-hidden"
      style={{
        background: "linear-gradient(135deg, #0f0c29, #302b63, #24243e)",
        fontFamily: "'Segoe UI', Tahoma, Geneva, Verdana, sans-serif",
        color: "#fff"
      }}
    >
      {/* --- Background Orbs --- */}
      <motion.div
        className="position-absolute rounded-circle"
        style={{
          width: "400px", height: "400px", background: "#00ff9d",
          filter: "blur(150px)", top: "-10%", right: "-10%", opacity: 0.15, zIndex: 0
        }}
        animate={{ scale: [1, 1.2, 1] }} transition={{ repeat: Infinity, duration: 8 }}
      />
      
      {/* --- Navbar --- */}
      <Navbar
        className="py-3 px-4 shadow-lg"
        style={{
          background: "rgba(255, 255, 255, 0.05)",
          backdropFilter: "blur(10px)",
          borderBottom: "1px solid rgba(255, 255, 255, 0.1)",
          zIndex: 10
        }}
      >
        <Container fluid className="d-flex justify-content-between align-items-center">
          <Navbar.Brand className="fw-bold text-white d-flex align-items-center gap-2">
            <UserPlus color="#00ff9d" />
            <span>Admin <span style={{ color: "#00ff9d" }}>/ Add User</span></span>
          </Navbar.Brand>
          
          <motion.button
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            className="btn btn-sm btn-outline-light d-flex align-items-center gap-2 rounded-pill px-3"
            onClick={() => navigate("/PMODashboard")}
            style={{ borderColor: "rgba(255,255,255,0.3)" }}
          >
            <ArrowLeft size={16} /> Back to Dashboard
          </motion.button>
        </Container>
      </Navbar>

      {/* --- Main Content --- */}
      <Container className="py-5 d-flex justify-content-center align-items-center flex-grow-1" style={{ zIndex: 5 }}>
        <motion.div
          initial={{ y: 50, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ duration: 0.8, type: "spring" }}
          className="p-4 p-md-5 rounded-4 shadow-lg w-100"
          style={{
            maxWidth: "700px",
            background: "rgba(255, 255, 255, 0.05)",
            backdropFilter: "blur(15px)",
            border: "1px solid rgba(255, 255, 255, 0.1)",
            boxShadow: "0 0 40px rgba(0,0,0,0.5)"
          }}
        >
          <h2 className="text-center mb-4 fw-bold">Create New Account</h2>

          {message && (
            <motion.div
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              className={`alert ${error ? 'alert-danger' : 'alert-success'} border-0 shadow-sm`}
            >
              {message}
            </motion.div>
          )}

          <Form onSubmit={handleSubmit}>
            <Row className="g-3">
              {/* Name */}
              <Col md={6}>
                <Form.Label className="small text-white-50 ms-1">Full Name</Form.Label>
                <div className="input-group">
                  <span className="input-group-text border-0" style={{ background: "rgba(255,255,255,0.1)", color: "#00ff9d" }}>
                    <User size={18} />
                  </span>
                  <Form.Control 
                    type="text" 
                    name="name" 
                    placeholder="Enter your Name" 
                    value={formData.name} 
                    onChange={handleChange} 
                    required 
                    style={inputStyle}
                    className="text-white shadow-none focus-ring"
                  />
                </div>
              </Col>

              {/* Email */}
              <Col md={6}>
                <Form.Label className="small text-white-50 ms-1">Email Address</Form.Label>
                <div className="input-group">
                  <span className="input-group-text border-0" style={{ background: "rgba(255,255,255,0.1)", color: "#00ff9d" }}>
                    <Mail size={18} />
                  </span>
                  <Form.Control 
                    type="email" 
                    name="email" 
                    placeholder="name@example.com" 
                    value={formData.email} 
                    onChange={handleChange} 
                    required 
                    style={inputStyle}
                    className="text-white shadow-none"
                  />
                </div>
              </Col>

              {/* Password */}
              <Col md={6}>
                <Form.Label className="small text-white-50 ms-1">Password</Form.Label>
                <div className="input-group">
                  <span className="input-group-text border-0" style={{ background: "rgba(255,255,255,0.1)", color: "#00ff9d" }}>
                    <Lock size={18} />
                  </span>
                  <Form.Control 
                    type="password" 
                    name="password" 
                    placeholder="Min 6 characters" 
                    value={formData.password} 
                    onChange={handleChange} 
                    required 
                    style={inputStyle}
                    className="text-white shadow-none"
                  />
                </div>
              </Col>

              {/* Role */}
              <Col md={6}>
                <Form.Label className="small text-white-50 ms-1">Assign Role</Form.Label>
                <div className="input-group">
                  <span className="input-group-text border-0" style={{ background: "rgba(255,255,255,0.1)", color: "#00ff9d" }}>
                    <Shield size={18} />
                  </span>
                  <Form.Select 
                    name="role" 
                    value={formData.role} 
                    onChange={handleChange} 
                    required 
                    style={inputStyle}
                    className="text-white shadow-none"
                  >
                    <option value="" style={{ color: "black" }}>Select Role</option>
                    <option value="student" style={{ color: "black" }}>Student</option>
                    <option value="supervisor" style={{ color: "black" }}>Supervisor</option>
                  </Form.Select>
                </div>
              </Col>
            </Row>

            {/* Conditional Supervisor Select */}
            {formData.role === "student" && (
              <motion.div 
                initial={{ height: 0, opacity: 0 }} 
                animate={{ height: "auto", opacity: 1 }} 
                className="mt-3"
              >
                <Form.Label className="small text-white-50 ms-1">Assign Supervisor</Form.Label>
                <Form.Select 
                  name="supervisorId" 
                  value={formData.supervisorId} 
                  onChange={handleChange} 
                  required 
                  style={inputStyle}
                  className="text-white shadow-none"
                >
                  <option value="" style={{ color: "black" }}>Select Supervisor</option>
                  {supervisors.map(s => (
                    <option key={s.id} value={s.id} style={{ color: "black" }}>{s.name}</option>
                  ))}
                </Form.Select>
              </motion.div>
            )}

            {/* Submit Button */}
            <motion.button
              type="submit"
              className="btn w-100 mt-4 fw-bold py-2 rounded-pill"
              style={{
                background: "linear-gradient(90deg, #00ff9d, #00d4ff)",
                border: "none",
                color: "#0f0c29",
                boxShadow: "0 0 15px rgba(0, 255, 157, 0.4)"
              }}
              whileHover={{ scale: 1.02, boxShadow: "0 0 25px rgba(0, 255, 157, 0.6)" }}
              whileTap={{ scale: 0.98 }}
            >
              <UserPlus size={20} className="me-2" /> Create User
            </motion.button>
          </Form>
        </motion.div>
      </Container>
    </div>
  );
}