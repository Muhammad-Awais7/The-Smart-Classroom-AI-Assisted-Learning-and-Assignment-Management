import React, { useEffect, useState } from "react";
import { useParams } from "react-router-dom";
import { getJoinRequests } from "../services/classroomService";
import { db } from "../firebase";
import { doc, updateDoc } from "firebase/firestore";

export default function ClassroomDetails() {

  const { id } = useParams();
  const [requests, setRequests] = useState([]);

  useEffect(() => {

    async function load() {
      const data = await getJoinRequests(id);
      setRequests(data);
    }

    load();

  }, [id]);


  const approveStudent = async (reqId) => {

    await updateDoc(doc(db, "classroomMembers", reqId), {
      status: "approved"
    });

    alert("Student Approved");
  };



  return (
    <div className="container mt-5">

      <h2>Join Requests</h2>

      {requests.map(r => (
        <div key={r.id} className="card p-3 mt-3">

          Student ID: {r.studentId}

          <button
            className="btn btn-success mt-2"
            onClick={() => approveStudent(r.id)}
          >
            Approve
          </button>

        </div>
      ))}

    </div>
  );
}
