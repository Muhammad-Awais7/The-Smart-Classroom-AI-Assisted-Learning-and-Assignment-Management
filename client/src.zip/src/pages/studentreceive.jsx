// src/pages/StudentAnnouncements.jsx
import React, { useEffect, useState } from "react";
import { db } from "../firebase";
import { collection, query, where, onSnapshot, orderBy } from "firebase/firestore";
import { useNavigate } from "react-router-dom";
import { Button, Card, Container, Row, Col } from "react-bootstrap";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faArrowLeft, faBullhorn } from "@fortawesome/free-solid-svg-icons";

export default function StudentAnnouncements() {
  const [announcements, setAnnouncements] = useState([]);
  const navigate = useNavigate();

  useEffect(() => {
    const q = query(
      collection(db, "roleAnnouncements"),
      where("visibleTo", "array-contains", "student"),
      orderBy("createdAt", "desc")
    );

    const unsubscribe = onSnapshot(q, (snapshot) => {
      setAnnouncements(snapshot.docs.map((doc) => ({ id: doc.id, ...doc.data() })));
    });

    return () => unsubscribe();
  }, []);

  return (
    <div
      className="d-flex flex-column min-vh-100"
      style={{ background: "linear-gradient(135deg, #f9fbfd, #eaf7ff)" }}
    >
      {/* Header */}
      <header
        className="py-3 px-4 d-flex justify-content-between align-items-center shadow-sm"
        style={{ backgroundColor: "#0056b3", color: "#ffffff" }}
      >
        <h3 className="m-0">
          <FontAwesomeIcon icon={faBullhorn} className="me-2" />
          Student Announcements
        </h3>
        <Button
          variant="light"
          onClick={() => navigate("/StudentDashboard")}
          className="fw-semibold"
        >
          <FontAwesomeIcon icon={faArrowLeft} className="me-2" />
          Back
        </Button>
      </header>

      {/* Main Content */}
      <Container className="flex-grow-1 py-5">
        <Row className="justify-content-center">
          <Col xs={12} md={10} lg={8}>
            {announcements.length === 0 ? (
              <div className="alert alert-info text-center shadow-sm rounded-3">
                No announcements yet.
              </div>
            ) : (
              announcements.map((a) => (
                <Card
                  key={a.id}
                  className="mb-4 shadow-sm border-0 rounded-4 bg-white"
                >
                  <Card.Body>
                    <Card.Title className="fw-bold text-primary">
                      {a.title || "Announcement"}
                    </Card.Title>
                    <Card.Text style={{ whiteSpace: "pre-wrap" }}>
                      {a.message}
                    </Card.Text>
                    {a.createdAt?.toDate && (
                      <p className="text-muted small mb-0">
                        📅 {a.createdAt.toDate().toLocaleString()}
                      </p>
                    )}
                  </Card.Body>
                </Card>
              ))
            )}
          </Col>
        </Row>
      </Container>

      {/* Footer */}
      <footer
        className="text-white text-center py-3 mt-auto"
        style={{ backgroundColor: "#003366" }}
      >
        <small>© 2025 Smart Past FYP Analyzer - Student Panel</small>
      </footer>
    </div>
  );
}
