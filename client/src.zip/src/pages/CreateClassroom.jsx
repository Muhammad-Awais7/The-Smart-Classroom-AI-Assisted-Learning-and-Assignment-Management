import React, { useState } from "react";
import { auth } from "../firebase";
import { createClassroom } from "../services/classroomService";

export default function CreateClassroom() {

  const [className, setClassName] = useState("");
  const [description, setDescription] = useState("");
  const [msg, setMsg] = useState("");

  const handleCreate = async () => {

    const supervisorId = auth.currentUser?.uid;

    if (!supervisorId) {
      alert("User not logged in");
      return;
    }

    if (!className) {
      alert("Enter classroom name");
      return;
    }

    try {

      await createClassroom({
        className,
        description,
        supervisorId
      });

      setMsg("Classroom Created");
      setClassName("");
      setDescription("");

    } catch (error) {
      console.error(error);
    }
  };

  return (
    <div className="container mt-5">

      <h2>Create Classroom</h2>

      <input
        className="form-control mt-3"
        placeholder="Class Name"
        value={className}
        onChange={(e) => setClassName(e.target.value)}
      />

      <textarea
        className="form-control mt-3"
        placeholder="Description"
        value={description}
        onChange={(e) => setDescription(e.target.value)}
      />

      <button
        className="btn btn-success mt-3"
        onClick={handleCreate}
      >
        Create Classroom
      </button>

      <p className="text-success mt-3">{msg}</p>

    </div>
  );
}
