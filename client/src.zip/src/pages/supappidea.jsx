// src/pages/SupervisorIdeas.jsx
import React, { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import "bootstrap/dist/css/bootstrap.min.css";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faArrowLeft, faClipboardList } from "@fortawesome/free-solid-svg-icons";
import { db } from "../firebase";
import {
  collection,
  onSnapshot,
  updateDoc,
  doc,
  getDoc,
} from "firebase/firestore";

const SupervisorIdeas = () => {
  const [ideas, setIdeas] = useState([]);
  const [messages, setMessages] = useState({}); // 🔹 stores reason/message per idea
  const supervisorId = "SUPERVISOR_123"; // 🔧 later replace with dynamic auth/props
  const navigate = useNavigate();

  useEffect(() => {
    const ideasRef = collection(db, "supervisors", supervisorId, "assignedIdeas");

    const unsubscribe = onSnapshot(ideasRef, async (snapshot) => {
      const ideasData = await Promise.all(
        snapshot.docs.map(async (docSnap) => {
          const idea = { id: docSnap.id, ...docSnap.data() };

          // fetch student details from users/{uid}
          if (idea.studentId) {
            const studentDoc = await getDoc(doc(db, "users", idea.studentId));
            if (studentDoc.exists()) {
              idea.studentName = studentDoc.data().name || "Unnamed Student";
              idea.studentEmail = studentDoc.data().email || "";
            } else {
              idea.studentName = "Unknown Student";
            }
          }
          return idea;
        })
      );
      setIdeas(ideasData);
    });

    return unsubscribe;
  }, []);

  const handleDecision = async (idea, decision) => {
    const reason = messages[idea.id] || ""; // get custom message

    // Update supervisor collection
    const ideaRef = doc(db, "supervisors", supervisorId, "assignedIdeas", idea.id);
    await updateDoc(ideaRef, { status: decision, reason });

    // Update student idea
    const studentIdeaRef = doc(
      db,
      "users",
      idea.studentId,
      "ideas",
      idea.ideaId
    );
    await updateDoc(studentIdeaRef, { status: decision, reason });

    // Clear input after decision
    setMessages((prev) => ({ ...prev, [idea.id]: "" }));
  };

  return (
    <div className="d-flex flex-column min-vh-100" style={{ backgroundColor: "#e8f5e9" }}>
      {/* Header */}
      <header
        className="py-3 px-4 d-flex justify-content-between align-items-center shadow"
        style={{ backgroundColor: "#2e7d32", color: "#ffffff" }}
      >
        <h3 className="m-0">
          <FontAwesomeIcon icon={faClipboardList} className="me-2" />
          Supervisor - Student Ideas
        </h3>
        <button
          onClick={() => navigate("/SupervisorDashboard")}
          className="btn btn-light text-success fw-semibold"
        >
          <FontAwesomeIcon icon={faArrowLeft} className="me-2" />
          Back
        </button>
      </header>

      {/* Main Content */}
      <main className="container flex-grow-1 py-5">
        <div className="row justify-content-center">
          <div className="col-12 col-md-10">
            {ideas.length === 0 ? (
              <div className="alert alert-info text-center">
                No student ideas submitted yet.
              </div>
            ) : (
              ideas.map((idea) => (
                <div key={idea.id} className="card border-0 shadow-sm mb-4">
                  <div className="card-body">
                    <h5 className="card-title text-success">{idea.title}</h5>
                    <p className="card-text">{idea.description}</p>
                    <p className="mb-1">
                      👤 <strong>{idea.studentName}</strong>{" "}
                      <span className="text-muted">({idea.studentEmail})</span>
                    </p>
                    <p className="mb-2">
                      Status:{" "}
                      <span
                        className={`badge ${
                          idea.status === "approved"
                            ? "bg-success"
                            : idea.status === "rejected"
                            ? "bg-danger"
                            : "bg-warning text-dark"
                        }`}
                      >
                        {idea.status}
                      </span>{" "}
                      {idea.reason && <span>💬 {idea.reason}</span>}
                    </p>

                    {idea.status === "pending" && (
                      <div>
                        {/* Message box */}
                        <textarea
                          className="form-control mb-2"
                          placeholder="Write a message for the student..."
                          value={messages[idea.id] || ""}
                          onChange={(e) =>
                            setMessages((prev) => ({
                              ...prev,
                              [idea.id]: e.target.value,
                            }))
                          }
                        />

                        {/* Buttons */}
                        <div className="d-flex gap-2">
                          <button
                            className="btn btn-success"
                            onClick={() => handleDecision(idea, "approved")}
                          >
                            Approve
                          </button>
                          <button
                            className="btn btn-danger"
                            onClick={() => handleDecision(idea, "rejected")}
                          >
                            Reject
                          </button>
                        </div>
                      </div>
                    )}
                  </div>
                </div>
              ))
            )}
          </div>
        </div>
      </main>

      {/* Footer */}
      <footer
        className="text-white text-center py-3 mt-auto"
        style={{ backgroundColor: "#1b5e20" }}
      >
        <small>© 2025 Smart Past FYP Analyzer - Supervisor Panel</small>
      </footer>
    </div>
  );
};

export default SupervisorIdeas;
