// src/components/SupervisorViewQuestions.jsx
import React, { useEffect, useState } from "react";
import "bootstrap/dist/css/bootstrap.min.css";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faChalkboardTeacher, faCheckCircle, faPaperPlane, faArrowLeft } from "@fortawesome/free-solid-svg-icons";
import { db, auth } from "../firebase";
import {
  collection,
  query,
  where,
  onSnapshot,
  updateDoc,
  doc,
  orderBy,
  getDoc,
} from "firebase/firestore";
import { useNavigate } from "react-router-dom";

const SupervisorViewQuestions = () => {
  const [questions, setQuestions] = useState([]);
  const [logs, setLogs] = useState([]);
  const [answers, setAnswers] = useState({});
  const navigate = useNavigate();

  // 🔹 Fetch all questions for this supervisor
  useEffect(() => {
    if (!auth.currentUser) return;

    const q = query(
      collection(db, "questions"),
      where("supervisorUid", "==", auth.currentUser.uid),
      orderBy("createdAt", "desc")
    );

    const unsubscribe = onSnapshot(
      q,
      async (snapshot) => {
        const fetched = await Promise.all(
          snapshot.docs.map(async (d) => {
            const data = d.data();

            // ✅ Always fetch latest student name from "users" collection
            let studentName = data.studentName || "Student";
            try {
              const studentRef = doc(db, "users", data.studentUid);
              const studentSnap = await getDoc(studentRef);
              if (studentSnap.exists()) {
                studentName = studentSnap.data().name || studentName;
              }
            } catch (err) {
              console.error("Error fetching student name:", err);
            }

            return {
              id: d.id,
              ...data,
              studentName,
            };
          })
        );

        setQuestions(fetched);
        setLogs((prev) => [...prev, "✅ Questions updated in real-time"]);
      },
      (error) => {
        console.error("Error fetching questions:", error);
        setLogs((prev) => [...prev, `❌ Error: ${error.message}`]);
      }
    );

    return () => unsubscribe();
  }, []);

  // 🔹 Handle answer submission
  const handleAnswerSubmit = async (questionId) => {
    const answerText = answers[questionId];
    if (!answerText || !answerText.trim()) {
      alert("Please write an answer before submitting.");
      return;
    }

    try {
      const questionRef = doc(db, "questions", questionId);
      await updateDoc(questionRef, {
        answer: answerText,
        isRead: false, // ✅ student will decide when to mark as read
      });

      setLogs((prev) => [...prev, `✅ Answer submitted for Question ID: ${questionId}`]);
      setAnswers((prev) => ({ ...prev, [questionId]: "" }));
    } catch (err) {
      console.error("Error submitting answer:", err);
      setLogs((prev) => [...prev, `❌ Error submitting answer: ${err.message}`]);
    }
  };

  // 🔹 Mark as Read/Unread
  const markAsRead = async (questionId, status) => {
    try {
      const questionRef = doc(db, "questions", questionId);
      await updateDoc(questionRef, { isRead: status });
      setLogs((prev) => [
        ...prev,
        `ℹ️ Question ${questionId} marked as ${status ? "Read" : "Unread"} by Supervisor`,
      ]);
    } catch (err) {
      console.error("Error updating read status:", err);
      setLogs((prev) => [...prev, `❌ Error updating read status: ${err.message}`]);
    }
  };

  return (
    <div className="d-flex flex-column min-vh-100" style={{ backgroundColor: "#f3e5f5" }}>
      {/* 🔹 Header with Back Button */}
      <header
        className="py-3 px-4 d-flex justify-content-between align-items-center shadow"
        style={{ backgroundColor: "#6a1b9a", color: "#fff" }}
      >
        <h3 className="m-0">
          <FontAwesomeIcon icon={faChalkboardTeacher} className="me-2" />
          Supervisor Panel
        </h3>
        <button
          className="btn btn-light btn-sm"
          onClick={() => navigate("/SupervisorDashboard")}
        >
          <FontAwesomeIcon icon={faArrowLeft} className="me-1" />
          Back to Dashboard
        </button>
      </header>

      <main className="container flex-grow-1 py-5">
        <div className="row justify-content-center">
          <div className="col-12 col-md-10">
            {questions.length === 0 ? (
              <p className="text-muted text-center">No questions yet.</p>
            ) : (
              questions.map((q) => (
                <div
                  key={q.id}
                  className={`card border-0 shadow-sm mb-3 ${
                    q.isRead ? "border-success" : "border-warning"
                  }`}
                >
                  <div className="card-body">
                    <h6>
                      <strong>Student:</strong> {q.studentName}
                    </h6>
                    <p>
                      <strong>Question:</strong> {q.question}
                    </p>
                    <p>
                      <strong>Answer:</strong>{" "}
                      {q.answer ? (
                        <span className="text-success">{q.answer}</span>
                      ) : (
                        <span className="text-muted">Not answered yet</span>
                      )}
                    </p>

                    {/* Answer Form */}
                    {!q.answer && (
                      <div className="mb-2">
                        <textarea
                          className="form-control mb-2"
                          rows="2"
                          placeholder="Write your answer..."
                          value={answers[q.id] || ""}
                          onChange={(e) =>
                            setAnswers((prev) => ({
                              ...prev,
                              [q.id]: e.target.value,
                            }))
                          }
                        />
                        <button
                          className="btn btn-success w-100"
                          onClick={() => handleAnswerSubmit(q.id)}
                        >
                          <FontAwesomeIcon icon={faPaperPlane} className="me-2" />
                          Submit Answer
                        </button>
                      </div>
                    )}

                    {/* Mark as Read/Unread */}
                    <button
                      className={`btn btn-sm mt-2 ${
                        q.isRead ? "btn-secondary" : "btn-outline-secondary"
                      }`}
                      onClick={() => markAsRead(q.id, !q.isRead)}
                    >
                      <FontAwesomeIcon icon={faCheckCircle} className="me-1" />
                      {q.isRead ? "Mark as Unread" : "Mark as Read"}
                    </button>
                  </div>
                </div>
              ))
            )}

            {/* Logs */}
            
          </div>
        </div>
      </main>

      <footer
        className="text-white text-center py-3 mt-auto"
        style={{ backgroundColor: "#4a148c" }}
      >
        <small>© 2025 Smart Past FYP Analyzer - Supervisor Panel</small>
      </footer>
    </div>
  );
};

export default SupervisorViewQuestions;
