// src/components/StudentAskQuestion.jsx
import React, { useState, useEffect } from "react";
import "bootstrap/dist/css/bootstrap.min.css";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import {
  faQuestionCircle,
  faPaperPlane,
  faCheckCircle,
  faEyeSlash,
  faArrowLeft,
} from "@fortawesome/free-solid-svg-icons";
import { useNavigate } from "react-router-dom";
import { db, auth } from "../firebase";
import {
  collection,
  addDoc,
  query,
  where,
  getDocs,
  serverTimestamp,
  orderBy,
  doc,
  getDoc,
  updateDoc,
} from "firebase/firestore";

const StudentAskQuestion = () => {
  const [question, setQuestion] = useState("");
  const [submitted, setSubmitted] = useState(false);
  const [questionsList, setQuestionsList] = useState([]);
  const [supervisor, setSupervisor] = useState(null);
  const [studentName, setStudentName] = useState("");
  const [logs, setLogs] = useState([]);
  const navigate = useNavigate();

  // 🔹 Fetch student's data + supervisor
  const fetchStudentAndSupervisor = async () => {
    if (!auth.currentUser) return;

    try {
      const studentDocRef = doc(db, "users", auth.currentUser.uid);
      const studentSnap = await getDoc(studentDocRef);
      if (studentSnap.exists()) {
        const studentData = studentSnap.data();
        setStudentName(studentData.name || "Student");

        if (studentData.supervisorId) {
          const supDocRef = doc(db, "users", studentData.supervisorId);
          const supSnap = await getDoc(supDocRef);
          if (supSnap.exists()) {
            const supData = supSnap.data();
            setSupervisor({
              uid: supData.uid,
              name: supData.name,
            });
          }
        }
      }
    } catch (err) {
      console.error("Error fetching supervisor:", err);
    }
  };

  // 🔹 Fetch questions
  const fetchQuestions = async () => {
    if (!auth.currentUser) return;

    try {
      const q = query(
        collection(db, "questions"),
        where("studentUid", "==", auth.currentUser.uid),
        orderBy("createdAt", "desc")
      );
      const snapshot = await getDocs(q);
      const questions = snapshot.docs.map((doc) => ({ id: doc.id, ...doc.data() }));
      setQuestionsList(questions);
    } catch (err) {
      console.error("Error fetching student questions:", err);
      setLogs((prev) => [...prev, `❌ Error fetching questions: ${err.message}`]);
    }
  };

  useEffect(() => {
    fetchStudentAndSupervisor();
    fetchQuestions();
  }, []);

  // 🔹 Submit question
  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!question.trim()) return alert("Please write a question before submitting.");
    if (!supervisor) return alert("No supervisor assigned.");

    try {
      await addDoc(collection(db, "questions"), {
        studentUid: auth.currentUser.uid,
        studentName: studentName, // ✅ correct name from Firestore
        supervisorUid: supervisor.uid,
        question: question,
        answer: "",
        isRead: false,
        createdAt: serverTimestamp(),
      });

      setQuestion("");
      setSubmitted(true);
      setLogs((prev) => [...prev, "✅ Question submitted successfully"]);
      setTimeout(() => setSubmitted(false), 3000);
      fetchQuestions();
    } catch (err) {
      console.error("Error submitting question:", err);
      setLogs((prev) => [...prev, `❌ Error submitting question: ${err.message}`]);
    }
  };

  // 🔹 Mark as Read (student side)
  const markAsRead = async (questionId) => {
    try {
      const qRef = doc(db, "questions", questionId);
      await updateDoc(qRef, { isRead: true });
      setLogs((prev) => [...prev, `ℹ️ Question ${questionId} marked as Read by Student`]);
      setQuestionsList((prev) => prev.filter((q) => q.id !== questionId)); // hide it
    } catch (err) {
      console.error("Error marking as read:", err);
      setLogs((prev) => [...prev, `❌ Error marking as read: ${err.message}`]);
    }
  };

  return (
    <div
      className="d-flex flex-column min-vh-100"
      style={{ backgroundColor: "#e3f2fd" }}
    >
      <header
        className="py-3 px-4 d-flex justify-content-between align-items-center shadow"
        style={{ backgroundColor: "#1976d2", color: "#fff" }}
      >
        <h3 className="m-0">
          <FontAwesomeIcon icon={faQuestionCircle} className="me-2" /> Ask Question
        </h3>

        {/* 🔙 Back Button */}
        <button
          onClick={() => navigate(-1)}
          className="btn btn-light btn-sm d-flex align-items-center"
          style={{ borderRadius: "20px", fontWeight: "500" }}
        >
          <FontAwesomeIcon icon={faArrowLeft} className="me-2" />
          Back
        </button>
      </header>

      <main className="container flex-grow-1 py-5">
        <div className="row justify-content-center">
          <div className="col-12 col-md-8 col-lg-6">
            {/* Submit Form */}
            <div className="card border-0 shadow-sm mb-4">
              <div className="card-body">
                <h5 className="card-title mb-4 text-primary">
                  <FontAwesomeIcon icon={faPaperPlane} className="me-2" /> Submit a Question
                </h5>
                <form onSubmit={handleSubmit}>
                  {supervisor && (
                    <div className="mb-3">
                      <label>Supervisor</label>
                      <input
                        type="text"
                        className="form-control"
                        value={supervisor.name}
                        disabled
                      />
                    </div>
                  )}
                  <div className="mb-3">
                    <textarea
                      className="form-control"
                      rows="4"
                      placeholder="Write your question here..."
                      value={question}
                      onChange={(e) => setQuestion(e.target.value)}
                      required
                    ></textarea>
                  </div>
                  <button type="submit" className="btn btn-primary w-100">
                    Submit
                  </button>
                </form>
                {submitted && (
                  <div className="alert alert-success mt-3 text-center">
                    Question submitted successfully!
                  </div>
                )}
              </div>
            </div>

            {/* Questions List */}
            {questionsList.map((q) => (
              <div
                key={q.id}
                className={`card border-0 shadow-sm mb-3 ${
                  q.isRead ? "border-success" : "border-warning"
                }`}
              >
                <div className="card-body">
                  <h6 className="mb-2">
                    {q.question}{" "}
                    {q.isRead && (
                      <FontAwesomeIcon
                        icon={faCheckCircle}
                        className="ms-2 text-success"
                      />
                    )}
                  </h6>
                  <p className="mb-0">
                    <strong>Answer:</strong>{" "}
                    {q.answer || (
                      <span className="text-muted">Not answered yet</span>
                    )}
                  </p>

                  {/* Show mark as read only if answer exists */}
                  {q.answer && !q.isRead && (
                    <button
                      className="btn btn-outline-secondary btn-sm mt-2"
                      onClick={() => markAsRead(q.id)}
                    >
                      <FontAwesomeIcon icon={faEyeSlash} className="me-1" />
                      Mark as Read
                    </button>
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>
      </main>

      <footer
        className="text-white text-center py-3 mt-auto"
        style={{ backgroundColor: "#0d47a1" }}
      >
        <small>© 2025 Smart Past FYP Analyzer - Student Panel</small>
      </footer>
    </div>
  );
};

export default StudentAskQuestion;
