import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Navbar, Container } from 'react-bootstrap';
import { 
  FaUserGraduate, 
  FaSignInAlt, 
  FaSearch, 
  FaBrain, 
  FaBell, 
  FaBook, 
  FaFileUpload,
  FaRobot,
  FaLightbulb,
  FaArrowRight,
  FaCalendarAlt,
  FaCommentDots
} from 'react-icons/fa';
import { auth, db } from '../firebase';
import { collection, query, where, getDocs } from 'firebase/firestore';
import { motion } from 'framer-motion';

const Studentdash = () => {
  const navigate = useNavigate();
  const [studentName, setStudentName] = useState("");
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchStudentData = async () => {
      if (!auth.currentUser) return;
      try {
        const q = query(
          collection(db, "users"),
          where("uid", "==", auth.currentUser.uid)
        );
        const querySnapshot = await getDocs(q);
        if (!querySnapshot.empty) {
          const studentData = querySnapshot.docs[0].data();
          setStudentName(studentData.name);
        } else {
          setStudentName("Student");
        }
      } catch (error) {
        console.error("Error fetching student data:", error);
        setStudentName("Student");
      } finally {
        setLoading(false);
      }
    };

    fetchStudentData();
  }, []);

  // --- Animation Variants ---
  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: { staggerChildren: 0.1 }
    }
  };

  const itemVariants = {
    hidden: { y: 20, opacity: 0 },
    visible: { y: 0, opacity: 1 }
  };

  // --- Dashboard Items Configuration ---
  const dashboardItems = [
    { 
      icon: FaSignInAlt, 
      label: "Main Page", 
      route: "/main", 
      color: "#00d4ff", 
      desc: "Go to landing page" 
    },

     { 
      icon: FaBook, 
      label: "Student join Classroom", 
      route: "/join-class",
      color: "#ff0000", 
      desc: "Classroom FOr Students" 
    },

     { 
      icon: FaBook, 
      label: "Student View Classroom", 
      route: "/student-classes",
      color: "#ff0000", 
      desc: "Classroom FOr Students" 
    },
  
    { 
      icon: FaBook, 
      label: "Report Analyzer", 
      route: "/studentnoti", 
      color: "#00d4ff", 
      desc: "Analyze documentation" 
    },
    { 
      icon: FaBell, 
      label: "Notifications", 
      route: "/studentreceive", 
      color: "#ff00cc", 
      desc: "View system alerts" 
    },
    { 
      icon: FaCommentDots, 
      label: "View Feedback", 
      route: "/studentfeedback", 
      color: "#ff00cc", 
      desc: "Supervisor remarks" 
    },
    { 
      icon: FaFileUpload, 
      label: "Ask Supervisor", 
      route: "/studentupload", 
      color: "#00ff9d", 
      desc: "Submit queries" 
    },
    { 
      icon: FaRobot, 
      label: "ChatBot AI", 
      route: "/chatbot", 
      color: "#bd00ff", 
      desc: "Get instant help" 
    },
  
  ];

  if (loading) {
    return (
      <div className="d-flex justify-content-center align-items-center vh-100 bg-dark text-white">
        <motion.h3 animate={{ opacity: [0.5, 1, 0.5] }} transition={{ repeat: Infinity, duration: 1.5 }}>
          Loading Dashboard...
        </motion.h3>
      </div>
    );
  }

  return (
    <div
      className="d-flex flex-column min-vh-100 position-relative overflow-hidden"
      style={{
        background: "linear-gradient(135deg, #0f0c29, #302b63, #24243e)",
        fontFamily: "'Segoe UI', Tahoma, Geneva, Verdana, sans-serif",
        color: "#fff"
      }}
    >
      {/* --- Background Animated Orbs --- */}
      <motion.div
        className="position-absolute rounded-circle"
        style={{
          width: "500px", height: "500px", background: "#00d4ff", // Cyan Orb
          filter: "blur(180px)", top: "-15%", left: "-10%", opacity: 0.15, zIndex: 0
        }}
        animate={{ scale: [1, 1.2, 1], x: [0, 30, 0] }}
        transition={{ repeat: Infinity, duration: 15 }}
      />
      <motion.div
        className="position-absolute rounded-circle"
        style={{
          width: "400px", height: "400px", background: "#bd00ff", // Purple Orb
          filter: "blur(150px)", bottom: "-10%", right: "-10%", opacity: 0.15, zIndex: 0
        }}
        animate={{ scale: [1, 1.1, 1], y: [0, -40, 0] }}
        transition={{ repeat: Infinity, duration: 12 }}
      />

      {/* --- Navbar --- */}
      <motion.header
        className="py-3 px-4 shadow-lg d-flex justify-content-between align-items-center"
        style={{
          background: "rgba(255, 255, 255, 0.05)",
          backdropFilter: "blur(10px)",
          borderBottom: "1px solid rgba(255, 255, 255, 0.1)",
          zIndex: 10
        }}
        initial={{ y: -50, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
      >
        <h3 className="m-0 fw-bold d-flex align-items-center text-white">
          <div 
            className="d-flex align-items-center justify-content-center rounded-circle me-3"
            style={{ width: '45px', height: '45px', background: 'rgba(255,255,255,0.1)' }}
          >
            <FaUserGraduate style={{ color: "#00d4ff" }} />
          </div>
          Welcome, <span className="text-info ms-2">{studentName}</span>
        </h3>
        
        <button 
            className="btn btn-outline-light btn-sm rounded-pill px-3"
            onClick={() => navigate("/")}
            style={{ borderColor: "rgba(255,255,255,0.3)" }}
        >
            Logout
        </button>
      </motion.header>

      {/* --- Main Content --- */}
      <main className="flex-grow-1 container py-5 position-relative" style={{ zIndex: 5 }}>
        
        <motion.div 
            className="text-center mb-5"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
        >
          <h2 className="fw-bold display-5">Student Dashboard</h2>
          <p className="text-white-50 fs-5">Select an action to proceed</p>
        </motion.div>

        <motion.div 
          className="row g-4 justify-content-center"
          variants={containerVariants}
          initial="hidden"
          animate="visible"
        >
          {dashboardItems.map((item, idx) => (
            <div className="col-md-6 col-lg-4 col-xl-3" key={idx}>
              <motion.div
                variants={itemVariants}
                whileHover={{ 
                    y: -10, 
                    boxShadow: `0 0 30px ${item.color}60`,
                    borderColor: item.color 
                }}
                whileTap={{ scale: 0.98 }}
                onClick={() => navigate(item.route)}
                className="card h-100 p-4 border-0 text-start text-white position-relative overflow-hidden"
                style={{
                  background: "rgba(255, 255, 255, 0.05)",
                  backdropFilter: "blur(15px)",
                  border: "1px solid rgba(255, 255, 255, 0.1)",
                  borderRadius: "20px",
                  cursor: "pointer"
                }}
              >
                {/* Icon Container */}
                <div 
                    className="mb-3 rounded-circle d-flex align-items-center justify-content-center"
                    style={{ 
                        width: '50px', 
                        height: '50px', 
                        background: `${item.color}20`,
                        border: `1px solid ${item.color}40`,
                        color: item.color 
                    }}
                >
                    <item.icon size={24} />
                </div>

                <div className="d-flex justify-content-between align-items-center mb-2">
                    <h5 className="fw-bold mb-0 text-truncate" title={item.label}>{item.label}</h5>
                    <FaArrowRight className="text-white-50 small" />
                </div>
                
                <p className="small text-white-50 mb-0" style={{ fontSize: '0.85rem' }}>{item.desc}</p>
                
                {/* Hover Glow Effect overlay */}
                <div 
                    className="position-absolute bottom-0 end-0 p-5"
                    style={{
                        background: item.color,
                        filter: "blur(60px)",
                        opacity: 0.1,
                        borderRadius: "50%"
                    }}
                />
              </motion.div>
            </div>
          ))}
        </motion.div>
      </main>

      {/* --- Footer --- */}
      <motion.footer
        className="text-white text-center py-3"
        style={{
            background: "rgba(0,0,0,0.2)",
            backdropFilter: "blur(5px)",
            borderTop: "1px solid rgba(255, 255, 255, 0.05)"
        }}
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 1 }}
      >
        <small className="opacity-50">© 2025 Smart Past FYP Analyzer - Student Panel</small>
      </motion.footer>
    </div>
  );
};

export default Studentdash;