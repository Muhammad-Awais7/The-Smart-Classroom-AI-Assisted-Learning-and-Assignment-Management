// src/pages/PmoUploadIdea.jsx
import React, { useState } from "react";
import { db } from "../firebase";
import { collection, addDoc, serverTimestamp } from "firebase/firestore";
import { Container, Form, Button, Alert, Card } from "react-bootstrap";
import { useNavigate } from "react-router-dom";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faUpload } from "@fortawesome/free-solid-svg-icons";
import { motion } from "framer-motion";

export default function PmoUploadIdea() {
  const [groupId, setGroupId] = useState("");
  const [members, setMembers] = useState("");
  const [supervisor, setSupervisor] = useState("");
  const [idea, setIdea] = useState("");
  const [description, setDescription] = useState("");
  const [success, setSuccess] = useState("");
  const [error, setError] = useState("");
  const navigate = useNavigate();

  const handleSubmit = async (e) => {
    e.preventDefault();
    setSuccess("");
    setError("");

    try {
      await addDoc(collection(db, "studentIdeas"), {
        groupId,
        members: members.split(",").map((m) => m.trim()), // CSV -> array
        supervisorName: supervisor,
        idea,
        description,
        createdAt: serverTimestamp(),
      });
      setSuccess("✅ Idea uploaded successfully!");
      setGroupId("");
      setMembers("");
      setSupervisor("");
      setIdea("");
      setDescription("");
    } catch (err) {
      console.error(err);
      setError("❌ Failed to upload idea. Try again.");
    }
  };

  return (
    <div
      className="d-flex flex-column min-vh-100 position-relative overflow-hidden"
      style={{
        background: "linear-gradient(135deg, #e6f2ff, #f8fbff)",
      }}
    >
      {/* Header */}
      <motion.header
        className="py-3 px-4 d-flex justify-content-between align-items-center shadow"
        style={{ backgroundColor: "#0077b6", color: "#ffffff" }}
        initial={{ y: -80, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ duration: 1 }}
      >
        <h2 className="m-0 fw-bold d-flex align-items-center">
          <motion.span
            initial={{ rotate: -180, opacity: 0 }}
            animate={{ rotate: 0, opacity: 1 }}
            transition={{ duration: 1.2, type: "spring" }}
            className="me-2 d-inline-block"
          >
            <FontAwesomeIcon icon={faUpload} />
          </motion.span>
          PMO - Upload Student Idea
        </h2>

        <Button
          variant="light"
          className="rounded-3 fw-bold text-primary"
          onClick={() => navigate(-1)}
        >
          ⬅ Back
        </Button>
      </motion.header>

      {/* Main Content */}
      <main className="flex-grow-1 container py-5 position-relative">
        <motion.div
          className="d-flex justify-content-center"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 1 }}
        >
          <Card
            className="shadow border-0 rounded-4 w-100"
            style={{ maxWidth: "600px", backgroundColor: "#ffffff" }}
          >
            <Card.Body>
              <h3
                className="text-center fw-bold mb-4"
                style={{ color: "#0077b6" }}
              >
                Upload Student Idea
              </h3>

              {success && <Alert variant="success">{success}</Alert>}
              {error && <Alert variant="danger">{error}</Alert>}

              <Form onSubmit={handleSubmit}>
                {/* Group ID */}
                <Form.Group className="mb-3">
                  <Form.Label>Group ID</Form.Label>
                  <Form.Control
                    type="text"
                    value={groupId}
                    onChange={(e) => setGroupId(e.target.value)}
                    required
                  />
                </Form.Group>

                {/* Group Members */}
                <Form.Group className="mb-3">
                  <Form.Label>Group Members (comma separated)</Form.Label>
                  <Form.Control
                    type="text"
                    value={members}
                    onChange={(e) => setMembers(e.target.value)}
                    placeholder="e.g. Ali , Aslam"
                    required
                  />
                </Form.Group>

                {/* Supervisor Name */}
                <Form.Group className="mb-3">
                  <Form.Label>Supervisor Name</Form.Label>
                  <Form.Control
                    type="text"
                    value={supervisor}
                    onChange={(e) => setSupervisor(e.target.value)}
                    placeholder="e.g. Mr. Atif"
                    required
                  />
                </Form.Group>

                {/* Project Idea */}
                <Form.Group className="mb-3">
                  <Form.Label>Project Idea</Form.Label>
                  <Form.Control
                    type="text"
                    value={idea}
                    onChange={(e) => setIdea(e.target.value)}
                    required
                  />
                </Form.Group>

                {/* Description */}
                <Form.Group className="mb-4">
                  <Form.Label>Description</Form.Label>
                  <Form.Control
                    as="textarea"
                    rows={3}
                    value={description}
                    onChange={(e) => setDescription(e.target.value)}
                  />
                </Form.Group>

                <Button
                  type="submit"
                  className="w-100 rounded-3 fw-bold py-2"
                  style={{
                    background: "linear-gradient(90deg,#00b4d8,#0077b6)",
                    border: "none",
                  }}
                >
                  Upload Idea
                </Button>
              </Form>
            </Card.Body>
          </Card>
        </motion.div>

        {/* Floating background shapes */}
        <motion.div
          className="position-absolute bg-primary rounded-circle"
          style={{ width: "70px", height: "70px", top: "12%", left: "8%", opacity: 0.15 }}
          animate={{ y: [0, 20, 0], x: [0, 10, 0] }}
          transition={{ repeat: Infinity, duration: 6 }}
        />
        <motion.div
          className="position-absolute bg-info rounded-circle"
          style={{ width: "90px", height: "90px", bottom: "15%", right: "10%", opacity: 0.15 }}
          animate={{ y: [0, -25, 0], x: [0, -15, 0] }}
          transition={{ repeat: Infinity, duration: 8 }}
        />
      </main>

      {/* Footer */}
      <motion.footer
        className="text-white text-center py-3 mt-auto"
        style={{ backgroundColor: "#023e8a" }}
        initial={{ y: 80, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ duration: 1 }}
      >
        <small>© 2025 Smart Past FYP Analyzer - PMO Panel</small>
      </motion.footer>
    </div>
  );
}
