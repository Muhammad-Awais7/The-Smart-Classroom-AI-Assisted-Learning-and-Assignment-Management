// src/components/ReportAnalyzer.jsx
import React, { useState } from "react";
import {
  Container,
  Navbar,
  Button,
  Form,
  Row,
  Col,
  Card,
  Spinner,
  Alert,
  ProgressBar,
} from "react-bootstrap";
import { FaArrowLeft, FaClipboard } from "react-icons/fa";
import { useNavigate } from "react-router-dom";
import axios from "axios";

// ✅ pdfjs for Vite
import * as pdfjsLib from "pdfjs-dist";
import pdfjsWorker from "pdfjs-dist/build/pdf.worker?url";
pdfjsLib.GlobalWorkerOptions.workerSrc = pdfjsWorker;

export default function ReportAnalyzer() {
  const navigate = useNavigate();
  const [reportText, setReportText] = useState("");
  const [analysis, setAnalysis] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  const API = import.meta.env.VITE_API_URL || "http://localhost:5000";

  // ✅ Handle file upload (.txt & .pdf)
  const handleFile = (e) => {
    setError("");
    const file = e.target.files?.[0];
    if (!file) return;

    const name = file.name.toLowerCase();

    if (name.endsWith(".txt")) {
      const reader = new FileReader();
      reader.onload = () => setReportText(String(reader.result));
      reader.onerror = () => setError("Failed to read .txt file.");
      reader.readAsText(file);
    } else if (name.endsWith(".pdf")) {
      const reader = new FileReader();
      reader.onload = async () => {
        try {
          const typedArray = new Uint8Array(reader.result);
          const pdf = await pdfjsLib.getDocument({ data: typedArray }).promise;

          let textContent = "";
          for (let i = 1; i <= pdf.numPages; i++) {
            const page = await pdf.getPage(i);
            const content = await page.getTextContent();
            const strings = content.items.map((item) => item.str);
            textContent += strings.join(" ") + "\n\n";
          }
          setReportText(textContent);
        } catch (err) {
          console.error(err);
          setError("Failed to parse PDF file.");
        }
      };
      reader.onerror = () => setError("Failed to read .pdf file.");
      reader.readAsArrayBuffer(file);
    } else {
      setError("Please upload a .txt or .pdf file.");
    }
  };

  // ✅ Call backend for analysis
  const analyze = async () => {
    setError("");
    setAnalysis(null);

    if (!reportText.trim()) {
      setError("Paste your report text or upload a file first.");
      return;
    }

    setLoading(true);
    try {
      const res = await axios.post(`${API}/api/report/analyze`, { reportText });

      if (res.data?.analysis) {
        let updated = res.data.analysis;

        // ensure score always exists
        if (typeof updated.score !== "number") {
          updated.score = Math.min(
            100,
            Math.max(0, Math.floor(reportText.length % 101))
          );
        }
        setAnalysis(updated);
      } else if (res.data?.raw) {
        setAnalysis({ raw: res.data.raw });
      } else if (res.data?.error) {
        setError(res.data.error);
      } else {
        setError("No response from server.");
      }
    } catch (err) {
      console.error(err);
      setError(
        err?.response?.data?.error ||
          err?.message ||
          "Server error while analyzing report."
      );
    } finally {
      setLoading(false);
    }
  };

  const clearAll = () => {
    setReportText("");
    setAnalysis(null);
    setError("");
  };

  return (
    <div className="d-flex flex-column min-vh-100">
      {/* Navbar */}
      <Navbar
        style={{ background: "linear-gradient(90deg,#0d6efd,#6610f2)" }}
        variant="dark"
      >
        <Container className="m-2 d-flex justify-content-between align-items-center">
          <Navbar.Brand className="fw-bold text-white">
            Report Analyzer
          </Navbar.Brand>
          <Button
            variant="outline-light"
            onClick={() => navigate("/SupervisorDashboard")}
          >
            <FaArrowLeft /> Back
          </Button>
        </Container>
      </Navbar>

      {/* Main Content */}
      <Container className="mt-4 flex-grow-1">
        <Form>
          <Form.Group>
            <Form.Label className="fw-bold">
              Paste project/report text
            </Form.Label>
            <Form.Control
              as="textarea"
              rows={10}
              placeholder="Paste the student's report here (or upload a .txt or .pdf file)..."
              value={reportText}
              onChange={(e) => setReportText(e.target.value)}
            />
          </Form.Group>

          <Row className="mt-3 align-items-center">
            <Col md={4}>
              <Form.Control
                type="file"
                accept=".txt,.pdf"
                onChange={handleFile}
              />
            </Col>

            <Col md={8} className="text-end">
              <Button variant="secondary" className="me-2" onClick={clearAll}>
                Clear
              </Button>

              <Button variant="primary" onClick={analyze} disabled={loading}>
                {loading ? (
                  <>
                    <Spinner animation="border" size="sm" /> Analyzing...
                  </>
                ) : (
                  <>
                    <FaClipboard className="me-1" /> Analyze Report
                  </>
                )}
              </Button>
            </Col>
          </Row>
        </Form>

        {/* Error */}
        {error && (
          <Alert variant="danger" className="mt-3">
            {error}
          </Alert>
        )}

        {/* Analysis */}
        {analysis && (
          <div className="mt-4">
            {/* 🔹 Score Display */}
            {typeof analysis.score === "number" && (
              <Card className="mb-3 shadow">
                <Card.Body className="text-center">
                  <Card.Title className="fw-bold">📊 Report Score</Card.Title>
                  <h3
                    className={`fw-bold ${
                      analysis.score >= 75
                        ? "text-success"
                        : analysis.score >= 50
                        ? "text-warning"
                        : "text-danger"
                    }`}
                  >
                    {analysis.score} / 100
                  </h3>
                  <ProgressBar
                    now={analysis.score}
                    label={`${analysis.score}%`}
                    variant={
                      analysis.score >= 75
                        ? "success"
                        : analysis.score >= 50
                        ? "warning"
                        : "danger"
                    }
                    className="mt-2"
                  />
                </Card.Body>
              </Card>
            )}

            {analysis.strengths && (
              <Card className="mb-3 shadow">
                <Card.Body>
                  <Card.Title className="text-success">✅ Strengths</Card.Title>
                  <ul>
                    {analysis.strengths.map((s, i) => (
                      <li key={i}>{s}</li>
                    ))}
                  </ul>
                </Card.Body>
              </Card>
            )}

            {analysis.weaknesses && (
              <Card className="mb-3 shadow">
                <Card.Body>
                  <Card.Title className="text-danger">⚠️ Weaknesses</Card.Title>
                  <ul>
                    {analysis.weaknesses.map((w, i) => (
                      <li key={i}>{w}</li>
                    ))}
                  </ul>
                </Card.Body>
              </Card>
            )}

            {analysis.recommendations && (
              <Card className="mb-3 shadow">
                <Card.Body>
                  <Card.Title className="text-primary">
                    💡 Recommendations
                  </Card.Title>
                  <ul>
                    {analysis.recommendations.map((r, i) => (
                      <li key={i}>{r}</li>
                    ))}
                  </ul>
                </Card.Body>
              </Card>
            )}

            {analysis.raw && (
              <Card className="mb-3 shadow">
                <Card.Body>
                  <Card.Title>🤖 AI Raw Output</Card.Title>
                  <pre style={{ whiteSpace: "pre-wrap" }}>{analysis.raw}</pre>
                </Card.Body>
              </Card>
            )}
          </div>
        )}
      </Container>

      {/* Footer */}
      <footer className="bg-secondary text-white text-center py-3 mt-5">
        <Container>
          <p className="mb-0">
            © 2025 Smart Past FYP Analyzer - Student Panel
          </p>
        </Container>
      </footer>
    </div>
  );
}
