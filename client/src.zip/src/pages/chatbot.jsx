// src/components/StudentChatbot.jsx
import React, { useState, useRef, useEffect } from "react";
import "bootstrap/dist/css/bootstrap.min.css";
import { useNavigate } from "react-router-dom";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faArrowLeft, faPaperPlane, faPlus, faTrash } from "@fortawesome/free-solid-svg-icons";
import { auth, db } from "../firebase";
import {
  doc,
  collection,
  getDocs,
  addDoc,
  updateDoc,
  getDoc,
  deleteDoc,
} from "firebase/firestore";
import ReactMarkdown from "react-markdown";

const StudentChatbot = () => {
  const navigate = useNavigate();
  const [chats, setChats] = useState([]);
  const [activeChatId, setActiveChatId] = useState(null);
  const [messages, setMessages] = useState([]);
  const [input, setInput] = useState("");
  const [loading, setLoading] = useState(false);
  const chatEndRef = useRef(null);

  useEffect(() => {
    chatEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  useEffect(() => {
    const loadChats = async () => {
      const user = auth.currentUser;
      if (!user) return;

      const sessionsRef = collection(db, "chats", user.uid, "sessions");
      const snapshot = await getDocs(sessionsRef);
      const sessions = snapshot.docs.map((doc) => ({ id: doc.id, ...doc.data() }));

      setChats(sessions);
      if (sessions.length > 0 && !activeChatId) {
        setActiveChatId(sessions[0].id);
        setMessages(sessions[0].messages || []);
      }
    };
    loadChats();
  }, []);

  const handleSelectChat = async (chatId) => {
    setActiveChatId(chatId);
    const user = auth.currentUser;
    const chatDoc = await getDoc(doc(db, "chats", user.uid, "sessions", chatId));
    if (chatDoc.exists()) setMessages(chatDoc.data().messages || []);
  };

  const handleNewChat = async () => {
    const user = auth.currentUser;
    const sessionsRef = collection(db, "chats", user.uid, "sessions");

    const newChat = {
      title: "New Chat",
      messages: [
        {
          sender: "bot",
          text: `👋 Hi ${user.displayName || "Student"}! How can I help you today?`,
          timestamp: Date.now(),
        },
      ],
    };
    const docRef = await addDoc(sessionsRef, newChat);
    const chatId = docRef.id;

    setChats((prev) => [...prev, { id: chatId, ...newChat }]);
    setActiveChatId(chatId);
    setMessages(newChat.messages);
  };

  const handleDeleteChat = async (chatId) => {
    const user = auth.currentUser;
    if (!user) return;

    await deleteDoc(doc(db, "chats", user.uid, "sessions", chatId));
    setChats((prev) => prev.filter((c) => c.id !== chatId));
    if (activeChatId === chatId) {
      setActiveChatId(null);
      setMessages([]);
    }
  };

  const saveChat = async (updatedMessages) => {
    const user = auth.currentUser;
    if (!user || !activeChatId) return;
    const chatRef = doc(db, "chats", user.uid, "sessions", activeChatId);
    await updateDoc(chatRef, { messages: updatedMessages });
  };

  const handleSend = async () => {
    if (!input.trim() || !activeChatId) return;

    const userMsg = { sender: "user", text: input, timestamp: Date.now() };
    const updatedMessages = [...messages, userMsg];
    setMessages(updatedMessages);
    setInput("");
    setLoading(true);
    await saveChat(updatedMessages);

    try {
      const response = await fetch("http://localhost:5000/api/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ message: input }),
      });

      const data = await response.json();
      const botMsg = {
        sender: "bot",
        text: data.reply || "⚠️ Sorry, I couldn't process that.",
        timestamp: Date.now(),
      };

      const newMessages = [...updatedMessages, botMsg];
      setMessages(newMessages);
      await saveChat(newMessages);
    } catch (err) {
      console.error("Chat error:", err);
      const errorMsg = {
        sender: "bot",
        text: "⚠️ Sorry, I couldn't process that.",
        timestamp: Date.now(),
      };
      const newMessages = [...updatedMessages, errorMsg];
      setMessages(newMessages);
      await saveChat(newMessages);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="d-flex min-vh-100" style={{ backgroundColor: "#e6f2ff" }}>
      <aside
        className="p-3 border-end bg-white"
        style={{ width: "260px", overflowY: "auto", position: "fixed", height: "100%" }}
      >
        <button className="btn btn-primary w-100 mb-3" onClick={handleNewChat}>
          <FontAwesomeIcon icon={faPlus} className="me-2" /> New Chat
        </button>

        {chats.map((c) => (
          <div
            key={c.id}
            className={`d-flex justify-content-between align-items-center p-2 mb-2 rounded ${
              activeChatId === c.id ? "bg-primary text-white" : "bg-light"
            }`}
            style={{ cursor: "pointer" }}
          >
            <span onClick={() => handleSelectChat(c.id)}>{c.title}</span>
            <FontAwesomeIcon
              icon={faTrash}
              className="ms-2 text-danger"
              onClick={() => handleDeleteChat(c.id)}
            />
          </div>
        ))}
      </aside>

      <div className="d-flex flex-column flex-grow-1" style={{ marginLeft: "260px" }}>
        <header
          className="py-3 px-4 d-flex justify-content-between align-items-center shadow"
          style={{ backgroundColor: "#007bff", color: "#fff" }}
        >
          <h3 className="m-0">💬 Smart FYP Chatbot</h3>
          <button
            onClick={() => navigate("/StudentDashboard")}
            className="btn btn-light text-primary fw-semibold"
          >
            <FontAwesomeIcon icon={faArrowLeft} className="me-2" />
            Back
          </button>
        </header>

        <main className="flex-grow-1 px-3 py-3" style={{ overflowY: "auto", backgroundColor: "#f8fbff" }}>
          {messages.map((msg, idx) => (
            <div key={idx} className={`d-flex mb-3 ${msg.sender === "user" ? "justify-content-end" : "justify-content-start"}`}>
              <div
                className={`p-3 rounded-4 shadow-sm ${
                  msg.sender === "user" ? "bg-primary text-white" : "bg-white border text-dark"
                }`}
                style={{ maxWidth: "70%" }}
              >
                {msg.sender === "bot" ? <ReactMarkdown>{msg.text}</ReactMarkdown> : msg.text}
                <div className="small mt-1 text-muted" style={{ fontSize: "0.75rem" }}>
                  {new Date(msg.timestamp).toLocaleTimeString()}
                </div>
              </div>
            </div>
          ))}
          {loading && <div className="text-muted fst-italic">🤖 Bot is typing...</div>}
          <div ref={chatEndRef} />
        </main>

        <footer className="p-3 bg-white border-top">
          <div className="d-flex">
            <input
              type="text"
              className="form-control rounded-pill me-2"
              placeholder="Type your message..."
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={(e) => e.key === "Enter" && handleSend()}
            />
            <button className="btn btn-primary rounded-circle" onClick={handleSend} disabled={loading || !activeChatId}>
              <FontAwesomeIcon icon={faPaperPlane} />
            </button>
          </div>
        </footer>
      </div>
    </div>
  );
};

export default StudentChatbot;
