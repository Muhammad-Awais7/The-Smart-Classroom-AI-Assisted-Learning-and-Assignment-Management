import { db } from "../firebase";
import {
  addDoc,
  collection,
  query,
  where,
  getDocs,
  serverTimestamp
} from "firebase/firestore";


// Generate Random Class Code
const generateClassCode = () => {
  return Math.random().toString(36).substring(2, 8).toUpperCase();
};


export const getStudentClassrooms = async (studentId) => {

  const q = query(
    collection(db, "classroomMembers"),
    where("studentId", "==", studentId),
    where("status", "==", "approved")
  );

  const snap = await getDocs(q);

  return snap.docs.map(doc => doc.data());
};

// CREATE CLASSROOM
export const createClassroom = async ({
  className,
  description,
  supervisorId
}) => {

  const classCode = generateClassCode();

  await addDoc(collection(db, "classrooms"), {
    className,
    description,
    supervisorId,
    classCode,
    createdAt: serverTimestamp()
  });
};



// GET SUPERVISOR CLASSROOMS
export const getSupervisorClassrooms = async (supervisorId) => {

  const q = query(
    collection(db, "classrooms"),
    where("supervisorId", "==", supervisorId)
  );

  const snap = await getDocs(q);

  return snap.docs.map(doc => ({
    id: doc.id,
    ...doc.data()
  }));
};



// STUDENT JOIN REQUEST
export const requestJoinClassroom = async (classCode, studentId) => {

  // Find classroom using classCode
  const q = query(
    collection(db, "classrooms"),
    where("classCode", "==", classCode)
  );

  const snap = await getDocs(q);

  if (snap.empty) throw new Error("Invalid Class Code");

  const classroomId = snap.docs[0].id;

  // Add join request
  await addDoc(collection(db, "classroomMembers"), {
    classroomId,
    studentId,
    status: "pending",
    requestedAt: serverTimestamp()
  });
};



// GET JOIN REQUESTS FOR SUPERVISOR
export const getJoinRequests = async (classroomId) => {

  const q = query(
    collection(db, "classroomMembers"),
    where("classroomId", "==", classroomId),
    where("status", "==", "pending")
  );

  const snap = await getDocs(q);

  return snap.docs.map(doc => ({
    id: doc.id,
    ...doc.data()
  }));

  
};
