import { createClient } from "@supabase/supabase-js";

const supabaseUrl = "https://aztliuxmiuqjaohexojo.supabase.co";  // replace with your project URL
const supabaseAnonKey = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImF6dGxpdXhtaXVxamFvaGV4b2pvIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NTc0OTIwNDgsImV4cCI6MjA3MzA2ODA0OH0.OIEj9IynxtUWCjtUsSRk9Ib8pYNA0waxergmVI03DwM";                // replace with anon key

export const supabase = createClient(supabaseUrl, supabaseAnonKey);
