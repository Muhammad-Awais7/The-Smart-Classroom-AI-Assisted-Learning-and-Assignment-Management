// src/App.jsx
import React from 'react';
import { BrowserRouter, Routes, Route } from 'react-router-dom';
import SignIn from './pages/SignIn';
import MainRoles from './pages/MainRoles';
import StudentDashboard from './pages/StudentDashboard'; // reuse from before
import SupervisorDashboard from './pages/SupervisorDashboard';
import PMODashboard from './pages/PMODashboard';
import SupFeedback from './pages/supfeedback';
import SupApproveIdea from './pages/supappidea';
import SupReviewReps from './pages/supreviewreps';
import SupComment from './pages/supcomment';
import SupTrack from './pages/suptrack';
import SupMeeting from './pages/supmeeting';
import SupervisorLogin from './pages/supervisorlogin';
import SupNot from './pages/supnot';
import StudentN from './pages/studentnoti';
import PMOADD from './pages/pmoadduser';
import StudLog from './pages/studentlogin';
import PmoN from './pages/pmonoti';
import StudRec from './pages/studentreceive';
import StudFeed from './pages/studentfeedback';
import StudUpload from './pages/studentupload';
import PMOLog from './pages/pmologin';
import ChatBot from './pages/chatbot';
import PmoHod from './pages/pmohod';
import PmoIdea from './pages/pmoidea';
import CreateClassroom from "./pages/CreateClassroom";
import SupervisorClassrooms from "./pages/SupervisorClassrooms";
import StudentClassrooms from "./pages/StudentClassrooms";
import ClassroomDetails from "./pages/ClassroomDetails";
import StudentJoinClassroom from "./pages/StudentJoinClassroom";





const App = () => {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<SignIn />} />
        <Route path="/main" element={<MainRoles />} />
       <Route path="/StudentDashboard" element={<StudentDashboard />} />
       <Route path="/SupervisorDashboard" element={<SupervisorDashboard />} />
        <Route path="/PMODashboard" element={<PMODashboard />} />
        <Route path="/supfeedback" element={<SupFeedback />} />
         <Route path="/supappidea" element={<SupApproveIdea />} />
         <Route path="/supreviewreps" element={<SupReviewReps />} />
          <Route path="/supcomment" element={<SupComment />} />
          <Route path="/suptrack" element={<SupTrack />} />
          <Route path="/supmeeting" element={<SupMeeting />} />
          <Route path="/supervisorlogin" element={<SupervisorLogin />} />
           <Route path="/supnot" element={<SupNot />} />
              <Route path="/studentnoti" element={<StudentN/>}/>
              <Route path="/pmoadduser" element={<PMOADD/>}/>
              <Route path="/studentlogin" element={<StudLog/>}/>
              <Route path="/pmonoti" element={<PmoN/>}/>
              <Route path="/studentreceive" element={<StudRec/>}/>
              <Route path="/studentfeedback" element={<StudFeed/>}/>
              <Route path="/studentupload" element={<StudUpload/>}/>
              <Route path="/pmologin" element={<PMOLog/>}/>
              <Route path="/chatbot" element={<ChatBot/>}/>
                <Route path="/pmohod" element={<PmoHod/>}/>
                <Route path="/pmoidea" element={<PmoIdea/>}/>
                <Route path="/create-classroom" element={<CreateClassroom />} />
                <Route path="/supervisor-classes" element={<SupervisorClassrooms />} />
                <Route path="/student-classes" element={<StudentClassrooms />} />
                <Route path="/classroom/:id" element={<ClassroomDetails />} />
                <Route path="/join-class" element={<StudentJoinClassroom />} />
               
              
      
      </Routes>
    </BrowserRouter>
  );
};

export default App;
